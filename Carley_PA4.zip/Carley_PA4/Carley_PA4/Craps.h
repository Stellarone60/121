/*
Programmer name: Sarah Carley
Date made: 10/1/22
Date last modified: 10/4/22
Description: This is where the functions that allow Craps to work are declared and where we include certain libraries
*/


#ifndef CRAPS_H
#define CRAPS_H

#define _CRT_SECURE_NO_WARNINGS

//stdio.h is the general library
//time.h makes it so the rolls are actually random
//stdlib.h pulls a "random" number
#include<stdio.h>
#include<time.h>
#include<stdlib.h>

//The numbers are made into constants so they are not confused anywhere
#define DISPLAY 1
#define PLAY 2
#define EXIT 3

/*
 Function: print_menu()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function prints the menu for the game
 Input parameters: None
 Returns: The menu
 Preconditions: None
 Postconditions: The manu is printed
*/
void print_menu(void);

/*
 Function: print_game_rules()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function prints the gme rules for the game
 Input parameters: None
 Returns: The game rules
 Preconditions: None
 Postconditions: The game rules are printed
*/
void print_game_rules(void);

/*
 Function: get_menu_choice()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function receives the menu choice an loops the menu if the choice is not valid
 Input parameters: the manu choice
 Returns: The menu if the result is not 1, 2, or 3. The program continues otherwise
 Preconditions: The menu choice must be given
 Postconditions: The menu is repeatedly printed until a valid input is entered
*/
int get_menu_choice(int menu_choice);

/*
 Function: get_bank_balance()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function prompts the user for and receives their bank balance
 Input parameters: None
 Returns: The balance
 Preconditions: None
 Postconditions: The balance is returned
*/
double get_bank_balance(void);

/*
 Function: get_wager_amount()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function prompts the user for and receives their wagers
 Input parameters: None
 Returns: The wager
 Preconditions: None
 Postconditions: The wager is returned
*/
double get_wager_amount(void);

/*
 Function: check_wager_amount()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function finds out if the wager given is valid in comparison to the bank balance
 Input parameters: None
 Returns: WHether or not the wager is valid
 Preconditions: The wager and balance
 Postconditions: The true or false of whether the wager is valid is returned
*/
int check_wager_amount(double wager, double balance);

/*
 Function: roll_dice()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function rolls a six-sided die
 Input parameters: None
 Returns: The result
 Preconditions: None
 Postconditions: The result is returned
*/
int roll_die(void);

/*
 Function: calculate_sum_dice()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function calculates the sum of the two dice
 Input parameters: the two die values
 Returns: The the sum
 Preconditions: None
 Postconditions: The sum is returned
*/
int calculate_sum_dice(int die1_value, int die2_value);

/*
 Function: is_win_loss_or_point()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function determines whether the first roll is a win, a loss, or a point
 Input parameters: None
 Returns: Which result it is
 Preconditions: The sum of the two dice
 Postconditions: The resule is returned
*/
int is_win_loss_or_point(int sum_dice);

/*
 Function: adjust_bank_balance()
 Date Created: 10/4/22
 Date Last Modified: 10/4/22
 Description: This function adds or subtracts from the bank balance depending on a win or loss
 Input parameters: the bank balance, the wager amount, and if the wager amount needs to be added or subtracted
 Returns: The new bank balance
 Preconditions: The three input paramaters
 Postconditions: The bank balance is returned
*/
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract);

/*
 Function: is_point_loss_or_neither()
 Date Created: 10/4/22
 Date Last Modified: 10/4/22
 Description: This function determines whether the point roll is a win, loss, or neither
 Input parameters: The sum of the dice and the point value
 Returns: Which result it is
 Preconditions: The sum of the two dice and the point value
 Postconditions: The result is returned
*/
int is_point_loss_or_neither(int sum_dice, int point_value);

/*
 Function: chatter_messages()
 Date Created: 10/4/22
 Date Last Modified: 10/4/22
 Description: This function reads off chatter messages depending on what is happening
 Input parameters: The number of rolls, if it's a win or loss, the initial balance, and the current balance
 Returns: A chatter message
 Preconditions: The needed factors exist
 Postconditions: The chater message is printed
*/
void chatter_messages(int number_rolls, int win_loss_neither, double initial_bank_balance, double current_bank_balance);



#endif CRAPS_H