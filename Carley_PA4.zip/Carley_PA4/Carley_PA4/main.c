/*
Programmer name: Sarah Carley
Date made: 10/1/22
Date last modified: 10/10/22
Description: This is the main function where the functions will all be called in a certain order to run the game Craps
*/


#include "Craps.h"

int main(void)
{
	int menu_choice = 0, die1 = 0, die2 = 0, valid_wager = 0, point = 0, sum = 0, after_roll = 0, add_or_subract = 0, keep_rolling = 1,
		add_or_subtract = 0, result_point = -1, number_rolls = 0, initial_bank = 0;
	double bank_balance = 0.0, wager = 0.0;
	//Shows the menu and repeats until a valis input is made
	menu_choice = get_menu_choice(menu_choice);
	//Clears the screen
	system("cls");
	//Keeps the number rolls actually random
	srand((unsigned int)time(NULL));
	//While the player does not choose exit, the program will run
	while (menu_choice != 3)
	{
		switch (menu_choice)
		{
		case DISPLAY: print_game_rules();//This will display the rules when prompted
			printf("\n\n");
			break;
		case PLAY:
				
				bank_balance = get_bank_balance();
				keep_rolling = 1;
				initial_bank = bank_balance;
				printf("Your bank balance is: $%.2lf\n", bank_balance);//Receives and prints the amount of money in the bank
				while (keep_rolling == 1)
				{
					//Gets the wager
					wager = get_wager_amount();
					//Prints the wager
					printf("Your wager is: $%.2lf\n", wager);
					//Checks if said wager can be used
					valid_wager = check_wager_amount(wager, bank_balance);
					while (valid_wager == 0)
					{
						//If the wager is invalid, it starts a loop until a valid wager is made
						printf("That amount is above your balance. Please make a new wager.\n");
						wager = get_wager_amount();
						printf("Your wager is: $%.2lf\n", wager);
						valid_wager = check_wager_amount(wager, bank_balance);
					}
					//The dice is being rolled
					printf("Time to roll the dice!\n");
					//Pauses the system for readability
					system("pause");
					//Gets the results of the rolled die
					die1 = roll_die();
					die2 = roll_die();
					//Increases the number of rolls so the chatter message can read it later
					number_rolls += 1;
					//The sum of the dice is calculates
					sum = calculate_sum_dice(die1, die2);
					//The sum is printed
					printf("Die 1: %d\nDie 2: %d\nSum: %d\n\n", die1, die2, sum);
					//It is determined whether the player, won, lost, or has made point
					after_roll = is_win_loss_or_point(sum);
					if (after_roll == 1)
					{
						//The player has won
						add_or_subtract = 1;
						bank_balance = adjust_bank_balance(bank_balance, wager, add_or_subtract);
						//If the player has won then they receive more money in their bank
						chatter_messages(number_rolls, after_roll, initial_bank, bank_balance);
						//printf("You have won!\n");
						
						do
						{
							//The loop will continue until a valid input is made
							printf("Your new balance is $%.2lf. Would you like to:\n1: continue playing\n2: Quit\n", bank_balance);
							scanf("%d", &keep_rolling);
						} while (keep_rolling < 1 || keep_rolling > 2);
					}
					else if (after_roll == 0)
					{
						//The player has lost
						//Bank balance is subtracted from
						add_or_subtract = 0;
						bank_balance = adjust_bank_balance(bank_balance, wager, add_or_subtract);
						//If the player has lost they will be deducted the wager amount from their bank
						chatter_messages(number_rolls, after_roll, initial_bank, bank_balance);
						//printf("You have lost!\n");
						
						
						if (bank_balance > 0)
						{
							do
							{
								printf("Your new balance is $%.2lf. Would you like to:\n1: continue playing\n2: Quit\n", bank_balance);
								scanf("%d", &keep_rolling);
							} while (keep_rolling < 1 || keep_rolling > 2);
						}
						else
						{
							//If the player has run out of money, then this will happen and the player will be forced to stop
							printf("You are out of money! Big loss, game over!\n");
							keep_rolling = 0;
						}
					}
					else
					{
						//The player neither won nor lost
						printf("You have made point, now you will get to roll until you get either a winning or losing result.\n");
						//Sets the goal
						point = sum;
						result_point = -1;
						while (result_point == -1)
						{
							//Keeps the player rolling while they have neither won nor lost
							printf("You will now roll again.\n");
							system("pause");
							die1 = roll_die();
							die2 = roll_die();
							//The sum of the dice is calculated
							sum = calculate_sum_dice(die1, die2);
							//The sum is printed
							printf("Die 1: %d\nDie 2: %d\nSum: %d\n\n", die1, die2, sum);
							result_point = is_point_loss_or_neither(sum, point);
						}
						if (result_point == 1)
						{
							//The player matched point befpre getting 7 so they win
							add_or_subtract = 1;
							bank_balance = adjust_bank_balance(bank_balance, wager, add_or_subtract);
							//If the player has won then they receive more money in their bank
							chatter_messages(number_rolls, result_point, initial_bank, bank_balance);
							//printf("You have won!\n");
							
							do
							{
								printf("Your new balance is $%.2lf. Would you like to:\n1: continue playing\n2: Quit\n", bank_balance);
								scanf("%d", &keep_rolling);
							} while (keep_rolling < 1 || keep_rolling > 2);
						}
						else if (result_point == 0)
						{
							add_or_subtract = 0;
							bank_balance = adjust_bank_balance(bank_balance, wager, add_or_subtract);
							//If the player has lost they will be deducted the wager amount from their bank
							chatter_messages(number_rolls, result_point, initial_bank, bank_balance);
							//printf("You have lost!\n");
							
							if (bank_balance > 0)
							{
								do
								{
									printf("Your new balance is $%.2lf. Would you like to:\n1: continue playing\n2: Quit\n", bank_balance);
									scanf("%d", &keep_rolling);
								} while (keep_rolling < 1 || keep_rolling > 2);
								if (keep_rolling == 2)
								{
									result_point = -1;
								}
							}
							else
							{
								//Player is forced to stop once they have $0 in their bank
								printf("You are out of money! Big loss, game over!\n");
								keep_rolling = 0;
							}
						}
					}
				}


			break;
		}
		//This restarts the program with the menu choice if the player wants to go again
		system("pause");
		system("cls");
		menu_choice = get_menu_choice(menu_choice);
	}





	return 0;
}