/*
Programmer name: Sarah Carley
Date made: 10/1/22
Date last modified: 10/1/22
Description: This is where the functions that allow Craps to work are created
*/


#include "Craps.h"

/*
 Function: print_menu()                         
 Date Created: 10/1/22                                          
 Date Last Modified: 10/1/22                                      
 Description: This function prints the menu for the game              
 Input parameters: None                                    
 Returns: The menu                
 Preconditions: None                                       
 Postconditions: The manu is printed
*/
void print_menu(void)
{
	printf("1. Display rules\n");
	printf("2. Play Craps.\n");
	printf("3. Exit.\n");
}

/*
 Function: get_menu_choice()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function receives the menu choice an loops the menu if the choice is not valid
 Input parameters: the manu choice
 Returns: The menu if the result is not 1, 2, or 3. The program continues otherwise
 Preconditions: The menu choice must be given
 Postconditions: The menu is repeatedly printed until a valid input is entered
*/
int get_menu_choice(int menu_choice)
{
	do
	{
		print_menu();
		scanf("%d", &menu_choice);
	} while (menu_choice > EXIT || menu_choice < DISPLAY);
	return menu_choice;
}

/*
 Function: print_game_rules()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function prints the gme rules for the game
 Input parameters: None
 Returns: The game rules
 Preconditions: None
 Postconditions: The game rules are printed
*/
void print_game_rules(void)
{
	printf("This game is very confusing. At the beginning of this game, you will roll two dice. ");
	printf("If the result is a 7 or 11, you win! If the result is a 2, 3, or 12, you lose. You will place a gamble on the bets. ");
	printf("If you do not get a 7, 11, 2, 3, or 12, the number you have rolled becomes 'point' which becomes your goal. ");
	printf("If you reach a 7 while trying to get point, then you lose. If you get point bfore getting a 7, you win!");
}

/*
 Function: get_bank_balance()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function prompts the user for and receives their bank balance
 Input parameters: None
 Returns: The balance
 Preconditions: None
 Postconditions: The balance is returned
*/
double get_bank_balance(void)
{
	double balance = 0.0;
	printf("\n\nWhat is your current bank balance?\n");
	scanf("%lf", &balance);
	return balance;
}

/*
 Function: get_wager_amount()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function prompts the user for and receives their wagers
 Input parameters: None
 Returns: The wager
 Preconditions: None
 Postconditions: The wager is returned
*/
double get_wager_amount(void)
{
	double wager = 0.0;
	printf("\nWhat is your wager?\n");
	scanf("%lf", &wager);
	return wager;
}

/*
 Function: check_wager_amount()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function finds out if the wager given is valid in comparison to the bank balance
 Input parameters: None
 Returns: WHether or not the wager is valid
 Preconditions: The wager and balance
 Postconditions: The true or false of whether the wager is valid is returned
*/
int check_wager_amount(double wager, double balance)
{
	int valid = 0;
	if (wager <= balance)
	{
		valid = 1;
	}
	return valid;
}

/*
 Function: roll_dice()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function rolls a six-sided die
 Input parameters: None
 Returns: The result
 Preconditions: None
 Postconditions: The result is returned
*/
int roll_die(void)
{
	return rand() % 6 + 1;
}


/*
 Function: calculate_sum_dice()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function calculates the sum of the two dice
 Input parameters: the two die values
 Returns: The the sum
 Preconditions: None
 Postconditions: The sum is returned
*/
int calculate_sum_dice(int die1_value, int die2_value)
{
	return die1_value + die2_value;
}

/*
 Function: is_win_loss_or_point()
 Date Created: 10/1/22
 Date Last Modified: 10/1/22
 Description: This function determines whether the first roll is a win, a loss, or a point
 Input parameters: None
 Returns: Which result it is
 Preconditions: The sum of the two dice
 Postconditions: The resule is returned
*/
int is_win_loss_or_point(int sum_dice)
{
	int result = 0;
	if (sum_dice == 7 || sum_dice == 11)
	{
		result = 1;
	}
	else if (sum_dice == 2 || sum_dice == 3 || sum_dice == 12)
	{
		result = 0;
	}
	else
	{
		result = -1;
	}
	return result;
}


/*
 Function: adjust_bank_balance()
 Date Created: 10/4/22
 Date Last Modified: 10/4/22
 Description: This function adds or subtracts from the bank balance depending on a win or loss
 Input parameters: the bank balance, the wager amount, and if the wager amount needs to be added or subtracted
 Returns: The new bank balance
 Preconditions: The three input paramaters
 Postconditions: The bank balance is returned
*/
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract)
{
	if (add_or_subtract == 1)
	{
		bank_balance = bank_balance + wager_amount;
	}
	else if (add_or_subtract == 0)
	{
		bank_balance = bank_balance - wager_amount;
	}
	return bank_balance;
}

/*
 Function: is_point_loss_or_neither()
 Date Created: 10/4/22
 Date Last Modified: 10/4/22
 Description: This function determines whether the point roll is a win, loss, or neither
 Input parameters: The sum of the dice and the point value
 Returns: Which result it is
 Preconditions: The sum of the two dice and the point value
 Postconditions: The result is returned
*/
int is_point_loss_or_neither(int sum_dice, int point_value)
{
	int result = 0;
	if (sum_dice == point_value)
	{
		result = 1;
	}
	else if (sum_dice == 7)
	{
		result = 0;
	}
	else
	{
		result = -1;
	}
	return result;
}

/*
 Function: chatter_messages()
 Date Created: 10/4/22
 Date Last Modified: 10/4/22
 Description: This function reads off chatter messages depending on what is happening
 Input parameters: The number of rolls, if it's a win or loss, the initial balance, and the current balance
 Returns: A chatter message
 Preconditions: The needed factors exist
 Postconditions: The chater message is printed
*/
void chatter_messages(int number_rolls, int win_loss_neither, double initial_bank_balance, double current_bank_balance)
{
	if (number_rolls == 1 && win_loss_neither == 1)
	{
		printf("Look at you! Winning in the first round!\n");
	}
	else if (number_rolls > 1 && win_loss_neither == 1)
	{
		printf("You're on a roll! Why stop now?\n");
	}
	else if (number_rolls >= 1 && win_loss_neither == 0 && current_bank_balance != 0)
	{
		printf("Tough luck! I bet you can get it next round!\n");
	}
	else if (current_bank_balance > initial_bank_balance)
	{
		printf("Look at you go! You're at $%.2lf and your initial bank balance was $%.2lf!\n", current_bank_balance, initial_bank_balance);
	}
	else if (current_bank_balance < initial_bank_balance && current_bank_balance != 0)
	{
		printf("Look at that... You have $%.2lf and you started with $%.2lf. Maybe a larger bet is needed ;)\n", current_bank_balance, initial_bank_balance);
	}
	if (current_bank_balance == 0)
	{
		printf("What a shame!\n");
	}

}