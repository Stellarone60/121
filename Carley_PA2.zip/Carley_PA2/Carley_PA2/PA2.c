/*
	Description: This will be where all functions will be that the main file will call on
	The functions will all compute something with an equation given inputs from main.c
*/

#include "PA2.h"

/*
Function: find_series_resistance ()                                      
Date Created: 9/13/22
Date Last Modified: 9/13/22
Description: Given three integer inputs, this functions will take those inputs and 
	add them together to find the total series resistance of the three resistors
Input parameters: R1, R2, and R3 from main.c
Returns: the total series resistance
Preconditions: The numbers for the three resistors must be given
Postconditions: The total series resistance is returned
*/

int calculate_series_resistance(int res1, int res2, int res3)
{
	return res1 + res2 + res3;
}



/*
Function: calculate_total_sales_tax ()
Date Created: 9/13/22
Date Last Modified: 9/13/22
Description: Given the sales tax rate and the cost of the item, this function will multiply
	them together to get the sales tax rate
Input parameters: sales_tax_rate and item_cost from main.c
Returns: the total sales tax
Preconditions: The numbers for the sales tax rate and item cost must be given
Postconditions: The total sales tax is returned
*/

double calculate_total_sales_tax(double sales_tax_rate, double item_cost)
{
	return sales_tax_rate * item_cost;
}


/*
Function: calculate_volume_pyramid ()
Date Created: 9/13/22
Date Last Modified: 9/13/22
Description: Given the length, width, and height of the puramid, this function will multiply
	them all together and divide that result by 3 to receive the volume
Input parameters: pyramid_length, puramid_height, pyramid_width from main.c
Returns: the volume of the pyramid
Preconditions: The numbers for the length, width, and height must be given
Postconditions: The volume of the pyramid must be returned
*/

double calculate_volume_pyramid(double l, double w, double h)
{
	return (w * l * h) / 3;
}


/*
Function: total_parallel_resistance ()
Date Created: 9/13/22
Date Last Modified: 9/13/22
Description: Given the three resistors, this function will find the parallel resistance of the three
Input parameters: resistance1, resistance2, resistance3 from main.c
Returns: the parallel resistance
Preconditions: The numbers for the three resistors must be given
Postconditions: The parallel resistance must be returned
*/
double total_parallel_resistance(double r1, double r2, double r3)
{
	return  1 / (1 / r1 + 1 / r2 + 1 / r3);
}


/*
Function: final_encoded_character()
Date Created: 9/13/22
Date Last Modified: 9/13/22
Description: Given the plaintext character and the shift integer, the function will change the character to the encoded character
Input parameters: plaintext_character and shift_int from main.c
Returns: the encoded character
Preconditions: The plaintext character and shift integer must be given
Postconditions: The encoded character must be returned
*/

char final_encoded_character(char plaintext_character, int shift)
{
	return (plaintext_character - 'a') + 'A' - shift;
}


/*
Function: total_distance()
Date Created: 9/13/22
Date Last Modified: 9/13/22
Description: Given two points, this function will find and return the distance between them
Input parameters: x_value1, y_value1, x_value2, y_value2 from main.c
Returns: the distance between the two points
Preconditions: The coordinates must be given
Postconditions: The distance must be returned
*/

double total_distance(double x1, double y1, double x2, double y2)
{
	return sqrt(pow((x1 - x2), 2) + pow((y1 - y2), 2));
}


/*
Function: general_solution()
Date Created: 9/13/22
Date Last Modified: 9/13/22
Description: Given the inputs, they will be put into the equation y = y / (3/17) - z + x / (a % 2) + PI
	and the result will be shown
Input parameters: y, x, z, a from main.c
Returns: the value of y
Preconditions: The inputs must be given
Postconditions: The value of y must be returned
*/

double general_solution(double y, double x, double z, int a)
{
	return  y / ((double)3 / (double)17) - z + x / (a % 2) + PI;
}

