/*
Name: Sarah Carley
Class: CptS lec2
Date: 8/31/22
Description: This program will run numbers given by the user through equations. The user will put inputs in this file
	while the functions are called and the inputs are run through those (other files)
*/

#include "PA2.h"

int main(void)
{
	int resistance1 = 0, resistance2 = 0, resistance3 = 0, series_resistance = 0,
		shift_int = 0,
		a = 0;
	double total_sales_tax = 0.0, sales_tax_rate = 0.0, item_cost = 0.0,
		volume_pyramid = 0.0, pyramid_length = 0.0, pyramid_width = 0.0, pyramid_height = 0.0,
		parallel_resistance = 0.0,
		z = 0.0, x = 0.0, y = 0.0,
		distance = 0.0, x_value1 = 0.0, x_value2 = 0.0, y_value1 = 0.0, y_value2 = 0.0;
	char encoded_character = '0', plaintext_character = '0';



	//Step 1, resistance:

	//1. Prompt the user for resistance 1
	printf("Please insert the value for the first resistor: ");
	//2. Get resistance 1
	scanf("%d", &resistance1);
	//3. Prompt the user for resistance 2
	printf("Please insert the value for the second resistor: ");
	//4. Get resistance 2
	scanf("%d", &resistance2);
	//5. Prompt the user for resistance 3
	printf("Please insert the value for the third resistor: ");
	//6. Get reisitance 3
	scanf("%d", &resistance3);
	//7. Insert all integers into the equation
	series_resistance = calculate_series_resistance(resistance1, resistance2, resistance3);
	//8. Print the result
	printf("The series resistance (R1 + R2 + R3) = %d + %d + %d = %d", resistance1, resistance2, resistance3, series_resistance);



	//Step 2, tax:

	//Prompt the user for tax rate
	printf("\n\nPlease insert the tax rate: ");
	//Get the tax rate
	scanf("%lf", &sales_tax_rate);
	//Prompt the user for the cost of the item
	printf("Please insert the price of the item: ");
	//Get the cost
	scanf("%lf", &item_cost);
	//Put the results into the equation
	total_sales_tax = calculate_total_sales_tax(sales_tax_rate, item_cost);
	//Print the result
	printf("The total sales tax is: total sales tax = sales tax rate * item cost = %lf * %lf = %lf", sales_tax_rate, item_cost, total_sales_tax);



	//Step 3, volume of a right rectangular prisim

	//Prompt the user for the length of the pyramid
	printf("\n\nPlease insert the length of the pyramid: ");
	//Get the length
	scanf("%lf", &pyramid_length);
	//Prompt the user for the width
	printf("Please insert the width of the pyramid: ");
	//Get the width
	scanf("%lf", &pyramid_width);
	//Prompt the user for the height
	printf("Please insert he height of the pyramid: ");
	//Get the height
	scanf("%lf", &pyramid_height);
	//Insert the results into the equation
	volume_pyramid = calculate_volume_pyramid(pyramid_length, pyramid_width, pyramid_height);
	//print the final result
	printf("The volume of the pyramid (L * W * H) = (%lf * %lf * %lf) / 3  =  %lf", pyramid_length, pyramid_width, pyramid_height, volume_pyramid);



	//Step 4, parallel resistors

	//Prompt the user for resistor 1
	printf("\n\nPlease insert the integer value for resitor 1: ");
	//Get resistor 1
	scanf("%d", &resistance1);
	//prompt the user for resistor 2
	printf("Please insert the integer value for resistor 2: ");
	//Get resistor 2
	scanf("%d", &resistance2);
	//Prompt the user for resistor 3
	printf("PLease insert the integer value for resistor 3: ");
	//Get resistor 3
	scanf("%d", &resistance3);
	//Put the results into the equation
	parallel_resistance = total_parallel_resistance(resistance1, resistance2, resistance3);
	//Print the result
	printf("The parallel resistance = 1 / (1 / R1 + 1 / R2 + 1 / R3) = 1/(1/ %d +1/ %d +1/ %d)  =  %lf", resistance1, resistance2, resistance3, parallel_resistance);



	//Step 5, Character encoding

	//Prompt the user for the plaintext character
	printf("\n\nPlease insert a plain text character: ");
	//Get the plaintext character
	scanf(" %c", &plaintext_character);
	//Prompt the user for the shift int
	printf("Please insert the shift int: ");
	//Get the shift int
	scanf("%d", &shift_int);
	//Put them all into the equation
	encoded_character = final_encoded_character(plaintext_character, shift_int);
	//Print the result
	printf("The encoded character is encoded character = \n(plaintext character � 'a') + 'A' � shift int = ( %c - 'a') + 'A' - %d  =   %c", plaintext_character, shift_int, encoded_character);


	//Step 6, distance between two points

	//Prompt the user for the x1 value
	printf("\n\nPlease insert the x1 value: ");
	//Get x1
	scanf("%lf", &x_value1);
	//Prompt the user for the x2 value
	printf("Please insert the x2 value: ");
	//Get x2
	scanf("%lf", &x_value2);
	//Prompt the user for the y1 value
	printf("Please insert the y1 value: ");
	//Get y1
	scanf("%lf", &y_value1);
	//Prompt the user for y2 value
	printf("Please insert teh y2 value: ");
	//Get y2
	scanf("%lf", &y_value2);
	//Insert the values in the equation
	distance = total_distance(x_value1, y_value1, x_value2, y_value2);
	//Print the result
	printf("The distance between the two points = square root of ((x1 - x2)2 + (y1 - y2)2)  =\n square root of ((%lf - %lf)2 + (%lf - %lf)2)  =  %lf", x_value1, x_value2, y_value1, y_value2, distance);



	//Step 7, general equation

	//Prompt the user for a y value
	printf("\n\nPlease insert a y value: ");
	//Get the y value
	scanf("%lf", &y);
	//Prompt the user for an x value
	printf("Please insert an x value: ");
	//Get the x value
	scanf("%lf", &x);
	//Prompt the user for a z value
	printf("Please insert a z value: ");
	//Get the z value
	scanf("%lf", &z);
	//Prompt the user for the a (int) value
	printf("Please insert an a value (this is an integer): ");
	//Get the a value
	scanf("%d", &a);
	//Insert the values into the equation
	y = general_solution(y, x, z, a);
	//Print the result
	printf("The answer when y = y / (3/17) - z + x / (a mod 2) + PI = %lf", y);



	return 0;
}