/*
Description: This header file will include the statements and declare the functions that will be used in main
*/

#define PA2_H

#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include <math.h>
#define PI 3.14159

//Function declerations
int calculate_series_resistance(int res1, int res2, int res3);

double calculate_total_sales_tax(double sales_tax_rate, double item_cost);

double calculate_volume_pyramid(double l, double w, double h);

double total_parallel_resistance(double r1, double r2, double r3);

char final_encoded_character(char plaintext_character, int shift);

double total_distance(double x1, double y1, double x2, double y2);

double general_solution(double y, double x, double z, int a);