/*
Date last modified: 9/21/22
Description: This is where functions will be made
*/
#include "Header.h"





/*
 Function: double read_double ()
 Date Created: 9/18/22
 Date Last Modified:       9/18/22
 Description: This reads a floating-point value from the input.dat file
 Input parameters: a floating point value in input.dat
 Returns: the floating point number it reads
 Preconditions: There must be a value in input.dat
 Postconditions: The floating point value that was read
*/
double read_double(FILE* infile)
{
	double float_number = 0;

	fscanf(infile, "%lf", &float_number);

	return float_number;
}


/*
 Function: int read_integer ()
 Date Created: 9/18/22
 Date Last Modified:       9/18/22
 Description: This reads an integer value from the input.dat file
 Input parameters: an integer point value in input.dat
 Returns: the integer point number it reads
 Preconditions: There must be a value in input.dat
 Postconditions: The integer point value that was read
*/
int read_integer(FILE* infile)
{
	int integer_number = 0;

	fscanf(infile, "%d", &integer_number);

	return integer_number;
}



/*
 Function: double calculate_sum ()                 
 Date Created: 9/18/22                                         
 Date Last Modified:       9/18/22                                
 Description: This function calculates and returns the sum if five numbers
 Input parameters: Five numbers      
 Returns: The sum of the numbers                               
 Preconditions: The numbers must exist    
 Postconditions: The sum of the numbers                      
*/
double calculate_sum(double number1, double number2, double number3, double number4, double number5)
{
	return number1 + number2 + number3 + number4 + number5;
}

/*
 Function: double calculate_mean ()
 Date Created: 9/18/22
 Date Last Modified:       9/18/22
 Description: This function calculates and returns the mean of the given values
 Input parameters: The sum and the amount of numbers that added to make the sum
 Returns: The mean
 Preconditions: The numbers must exist
 Postconditions: The mean of the numbers
*/
double calculate_mean(double sum, int number)
{
	return sum / number;
}

/*
 Function: double calculate_deviation ()
 Date Created: 9/18/22
 Date Last Modified:       9/18/22
 Description: This function calculates and returns the deviation of the given values
 Input parameters: The number and the mean
 Returns: The deviation
 Preconditions: The numbers must exist
 Postconditions: The deviation of the numbers
*/
double calculate_deviation(double number, double mean)
{
	return number - mean;
}


/*
 Function: double calculate_variance ()
 Date Created: 9/18/22
 Date Last Modified:       9/18/22
 Description: This function calculates and returns the variance of the given values
 Input parameters: The 5 devations and the number
 Returns: The variance
 Preconditions: The numbers must exist
 Postconditions: The variance of the numbers
*/
double calculate_variance(double deviation1, double deviation2, double deviation3, double deviation4, double deviation5, int number)
{
	return (pow(deviation1, 2) + pow(deviation2, 2) + pow(deviation3, 2) + pow(deviation4, 2) + pow(deviation5, 2)) / number;
}


/*
 Function: double calculate_standard_deviation ()
 Date Created: 9/18/22
 Date Last Modified:       9/18/22
 Description: This function calculates and returns the standard deviation of the given values
 Input parameters: The variance
 Returns: The the standard deviation
 Preconditions: The variance must exist
 Postconditions: The standard deviation of the number
*/
double calculate_standard_deviation(double variance)
{
	return sqrt(variance);
}

/*
 Function: double find_max ()
 Date Created: 9/21/22
 Date Last Modified:       9/21/22
 Description: This function finds the max of the given values
 Input parameters: The 5 numbers
 Returns: The maximum
 Preconditions: The numbers must exist
 Postconditions: The max of the numbers
*/
double find_max(double num1, double num2, double num3, double num4, double num5)
{
	double max = 0.0;
	if (num1 > num2 && num1 > num3 && num1 > num4 && num1 > num5)
	{
		max = num1;
	}
	else if (num2 > num1 && num2 > num3 && num2 > num4 && num2 > num5)
	{
		max = num2;
	}
	else if (num3 > num1 && num3 > num2 && num3 > num4 && num3 > num5)
	{
		max = num3;
	}
	else if (num4 > num2 && num4 > num1 && num4 > num3 && num4 > num5)
	{
		max = num4;
	}
	else if (num5 > num2 && num5 > num1 && num5 > num4 && num5 > num3)
	{
		max = num5;
	}
	return max;
}



/*
 Function: double find_min ()
 Date Created: 9/21/22
 Date Last Modified:       9/21/22
 Description: This function finds the min of the given values
 Input parameters: The 5 numbers
 Returns: The minimum
 Preconditions: The numbers must exist
 Postconditions: The min of the numbers
*/
double find_min(double num1, double num2, double num3, double num4, double num5)
{
	double min = 0.0;
	if (num1 < num2 && num1 < num3 && num1 < num4 && num1 < num5)
	{
		min = num1;
	}
	else if (num2 < num1 && num2 < num3 && num2 < num4 && num2 < num5)
	{
		min = num2;
	}
	else if (num3 < num1 && num3 < num2 && num3 < num4 && num3 < num5)
	{
		min = num3;
	}
	else if (num4 < num2 && num4 < num1 && num4 < num3 && num4 < num5)
	{
		min = num4;
	}
	else if (num5 < num2 && num5 < num1 && num5 < num4 && num5 < num3)
	{
		min = num5;
	}
	return min;
}
