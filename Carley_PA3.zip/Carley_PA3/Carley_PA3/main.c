/*
Programmer: Sarah Carley
Date made: 9/17
Date last modified: 9/21
Description: This program will process numbers corresponding to student records from a file
*/
#include "Header.h"

int main(void)
{
	//Open an input file
	//Open an output file
	int id1 = 0, id2 = 0, id3 = 0, id4 = 0, id5 = 0, class1 = 0, class2 = 0, class3 = 0, class4 = 0, class5 = 0,
		class_sum = 0;
	double gpa1 = 0.0, gpa2 = 0.0, gpa3 = 0.0, gpa4 = 0.0, gpa5 = 0.0, age1 = 0.0, age2 = 0.0, age3 = 0.0, age4 = 0.0, age5 = 0.0,
		gpa_sum = 0.0, age_sum = 0.0, dev1 = 0.0, dev2 = 0.0, dev3 = 0.0, dev4 = 0.0, dev5 = 0.0,
		gpa_mean = 0.0, class_standing_mean = 0.0, age_mean = 0.0, standard_deviation = 0.0, variance = 0.0, min = 0.0, max = 0.0,
		deviation = 0.0;
	FILE *infile = fopen("input.dat", "r"),
		*outfile = fopen("output.dat", "w");


	//Read the ID number for the first student
	id1 = read_integer(infile);
	//Read the gpa for the first student
	gpa1 = read_double(infile);
	//Read the class standing for the first student
	class1 = read_integer(infile);
	//Read the age for the first student
	age1 = read_double(infile);
	
	//Read the ID number for the second student
	id2 = read_integer(infile);
	//Read the gpa for the second student
	gpa2 = read_double(infile);
	//Read the class standing for the second student
	class2 = read_integer(infile);
	//Read the age for the second student
	age2 = read_double(infile);

	//Read the ID number for the third student
	id3 = read_integer(infile);
	//Read the gpa for the third student
	gpa3 = read_double(infile);
	//Read the class standing for the third student
	class3 = read_integer(infile);
	//Read the age for the third student
	age3 = read_double(infile);

	//Read the ID number for the fourth student
	id4 = read_integer(infile);
	//Read the gpa for the fourth student
	gpa4 = read_double(infile);
	//Read the class standing for the fourth student
	class4 = read_integer(infile);
	//Read the age for the fourth student
	age4 = read_double(infile);

	//Read the ID number for the fifth student
	id5 = read_integer(infile);
	//Read the gpa for the fifth student
	gpa5 = read_double(infile);
	//Read the class standing for the fifth student
	class5 = read_integer(infile);
	//Read the age for the fifth student
	age5 = read_double(infile);
	//I do not know if all this repetition is necessary but better safe than sorry
	
	//Calculate the sum of the GPAs
	gpa_sum = calculate_sum(gpa1, gpa2, gpa3, gpa4, gpa5);
	//Calculate the sum of the class standings
	class_sum = calculate_sum((double)class1, (double)class2, (double)class3, (double)class4, (double)class5);
	//Calculate the sum of the ages
	age_sum = calculate_sum(age1, age2, age3, age4, age5);
	//Calculate the mean of the GPAs
	gpa_mean = calculate_mean(gpa_sum, 5);
	//Append the mean of the GPAs to output.dat
	outfile = fopen("output.dat", "a");
	fprintf(outfile, "GPA mean: %.2lf\n", gpa_mean);
	//Calculate the mean of the class standings
	class_standing_mean = calculate_mean(class_sum, 5);
	//Append the mean of the class standings to output.dat
	outfile = fopen("output.dat", "a");
	fprintf(outfile, "Class mean: %.2lf\n", class_standing_mean);
	//Calculate the mean of the ages
	age_mean = calculate_mean(age_sum, 5);
	//Append the mean to output.dat
	outfile = fopen("output.dat", "a");
	fprintf(outfile, "Age mean: %.2lf\n", age_mean);
	//Calculate the deviation of each GPA
	dev1 = calculate_deviation(gpa1, gpa_mean);
	dev2 = calculate_deviation(gpa2, gpa_mean);
	dev3 = calculate_deviation(gpa3, gpa_mean);
	dev4 = calculate_deviation(gpa4, gpa_mean);
	dev5 = calculate_deviation(gpa5, gpa_mean);
	//Calculate the variance of the GPAs
	variance = calculate_variance(dev1, dev2, dev3, dev4, dev5, 5);
	//Calculate the standard deviation of the GPAs
	standard_deviation = calculate_standard_deviation(variance);
	//Append the standard devation to output.dat
	outfile = fopen("output.dat", "a");
	fprintf(outfile, "Standard Deviation: %.2lf\n", standard_deviation);
	//Determine the min of the GPAs
	min = find_min(gpa1, gpa2, gpa3, gpa4, gpa5);
	//Append the min to output.dat
	outfile = fopen("output.dat", "a");
	fprintf(outfile, "Minimum: %.2lf\n", min);
	//Determine the max of the GPAs
	max = find_max(gpa1, gpa2, gpa3, gpa4, gpa5);
	//Append the max to output.dat
	outfile = fopen("output.dat", "a");
	fprintf(outfile, "Maximum: %.2lf\n", max);
	//Read five records from the input file (input.dat)
	//You will need to use a combination of read_double ( ) and read_integer ( ) function calls




	//Close the input and output files
	fclose(infile);
	fclose(outfile);

	return 0;
}