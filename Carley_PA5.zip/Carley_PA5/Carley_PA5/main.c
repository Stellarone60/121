/*
Programmer name: Sarah Carley
Date made: 10/20/22
Date last modified: 10/21/22
Description: This is the main function where the functions will all be called in a certain order to run the game
*/

//dice count array
//freq table
//two score cards

#include "yahtzee.h"


//Important: The order of the scores as well as the is done tables are
//ones, twos, threes, fours, fives, sixes, three of a kind, four of a kind, small straight, large straight, full house, yahtzee, chance
int main(void)
{
	//for the score tables, leave index 0 as 0
	int players = 0, p1_score[14] = { 0 }, p2_score[14] = {0}, rounds = 1, dice[5] = {0}, menu_choice = 0, after_roll = 0, valid = 0;
	int num_rolls = 1, rerolls = 0, player = 1, p_rounds = 1, loops = 0, p1_total_score = 0, p2_total_score = 0;
	char y_or_n = '\0';
	int p1_is_done[14] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };//All those pointers are not needed
	//int *small_st = 0, *lg_st = 0, *ones = 0, *twos = 0, *threes = 0, *fours = 0, *fives = 0, *sixes = 0, *three_of_kind = 0;
	//int *four_of_kind = 0, *full_house = 0, *chance = 0;

	int p2_is_done[14] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };//takes the place of the pointers, was weird when I only set it to 0
	//int* small_st2 = 0, * lg_st2 = 0, * ones2 = 0, * twos2 = 0, * threes2 = 0, * fours2 = 0, * fives2 = 0, * sixes2 = 0, * three_of_kind2 = 0;
	//int* four_of_kind2 = 0, * full_house2 = 0, * chance2 = 0;
	//For quick reference because this is a pain to type out
	//print_choices(ones, twos, threes, fours, fives, sixes, three_of_kind, four_of_kind, full_house, chance, small_st, lg_st);
	
	//Keeps the number rolls actually random
	srand((unsigned int)time(NULL));

	printf("Welcome to Yahtzee!\n");
	//goes to the function call of get menu choice, will loop until valid input is given
	menu_choice = get_menu_choice(menu_choice);

	//If the player does not want to quit, the program will be exited
	while (menu_choice != 3)
	{
		switch (menu_choice)
		{
		case DISPLAY: print_game_rules();//This will display the rules when prompted
			printf("\n\n");
			break;
		case PLAY:
			system("cls");
			do
			{
				//Gets how many player will be playing, will be very important
				printf("How many players? 1 or 2?\n");
				scanf("%d", &players);
			} while (players > 2 || players < 1);
			//Depending on the number of players, the number of rounds needed will be different
			//The loop will be exited once one of the conditions is met
			while (rounds < 14 && p_rounds < 27)
			{
				do
				{
					if (players == 2)
					{
						//With two players, there are more turns and those are going to be tracked
						printf("Round %d\n", p_rounds);
					}
					else
					{
						//This will print what round the player is on
						printf("Round %d\n", rounds);
					}
					printf("Time to roll, player %d!\n", player);
					//The dice are rolled
					roll_die(dice);
					//Th results are printed
					print_array(dice);
					//The system is paused
					system("pause");
					//This keeps track of rerolls
					while (num_rolls != 3)
					{
						//loops until a valid input is given
						do
						{
							//Asks if the player wants to reroll and gets the input
							printf("Would you like to use this roll to get points? Y or N:\n");
							scanf(" %c", &y_or_n);
						} while (y_or_n != 'Y' && y_or_n != 'y' && y_or_n != 'n' && y_or_n != 'N');
						//If yes, then the rest of this loop is skipped because it sets roll to 3
						if (y_or_n == 'y' || y_or_n == 'Y')
						{
							num_rolls = 3;
						}
						else if(y_or_n == 'N' || y_or_n == 'n')
						{
							//Asks how many dice want to be rerolled
							do
							{
								printf("How many dice would you like to reroll?\n");
								scanf("%d", &rerolls);
							} while (rerolls < 1 && rerolls > 5);
							//This calls the function that lets the player reroll dice based on their input
							rerolling(rerolls, dice);
							//This reprints the dice array
							print_array(dice);
							//Increases the number of rolls
							num_rolls++;
						}
					}
					//resets the number of rolls
					num_rolls = 1;
					do
					{
						//pause the system
						system("pause");
						//clear the screen
						system("cls");
						//Print the dice array again
						print_array(dice);
						//Check if the first player's choice is valid
						if (player == 1)
						{
							//Prints the player's choices based on what they have done and gets it
							print_choices(p1_is_done);
							scanf("%d", &after_roll);
							//Determines whether the choice is valid
							valid = is_choice_valid(after_roll, p1_is_done);
						}
						else
							//Checks if the second player's choice is valid
						{
							//Prints the player's choices based on what they have done and gets it
							print_choices(p2_is_done);
							scanf("%d", &after_roll);
							//Determines whether the choice is valid
							valid = is_choice_valid(after_roll, p2_is_done);
						}
					} while (after_roll < 1 || after_roll > 13 || valid == 1);
					if (player == 1)
					{
						//Determines the first player's score and prints it
						process_choice_score(after_roll, p1_is_done, p1_score, dice);
						print_scores(p1_score, player);
					}
					else
					{
						//Determines the second player's score and prints it
						process_choice_score(after_roll, p2_is_done, p2_score, dice);
						print_scores(p2_score, player);
					}
					//Pauses and clears the system
					system("pause");
					system("cls");
					if (player == 2)
					{
						//Changes the player
						player = 1;
					}
					else if (players == 2 && player == 1)
					{
						//Changes the player if there are two players and the current player is 1
						player = 2;
					}
					if (players == 2)
					{
						//Changes the rounds for a two player game
						p_rounds++;
					}
					else
					{
						//changes the rounds for a one player game
						rounds++;
					}
				} while (players == 2 && p_rounds < 27);
				//rounds++;
			}
			//This is where the winner will be calculated
			//calculates the first player's score
			p1_total_score = calculate_final_score(p1_score);
			//Will determine a winner if there are two players
			if (players == 2)
			{
				//calculates and prints the scores
				p2_total_score = calculate_final_score(p2_score);
				printf("Player 1 score: %d\nPlayer 2 score: %d\n", p1_total_score, p2_total_score);
				//determines the winner
				if (p1_total_score > p2_total_score)
				{
					//Prints if the first player wins
					printf("Player 1 wins!!!");
				}
				else if (p1_total_score < p2_total_score)
				{
					//prints if the second player wins
					printf("Player 2 wins!!!");
				}
				else
				{
					//prints if the scores were the same
					printf("It has ended in a tie! Play rock paper sissors to find the true victor or something!");
				}
			}
			//if there is only one player
			else
			{
				//print their score
				printf("You have completed Yahtzee with a total of %d points! Good job!\n", p1_total_score);
			}

		}
		//This restarts the program with the menu choice if the player wants to go again
		system("pause");
		system("cls");
		//Get them back to the menu choice in case they want to replay
		menu_choice = get_menu_choice(menu_choice);
	}



	return 0;
}