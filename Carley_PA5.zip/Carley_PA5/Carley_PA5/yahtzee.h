/*
Programmer name: Sarah Carley
Date made: 10/20/22
Date last modified: 10/21/22
Description: This is the header where funtions will be initialized and libraries defined
*/

#ifndef YAHTZEE_H
#define YAHTZEE_H

#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include<time.h>
#include<stdlib.h>

//The numbers are made into constants so they are not confused anywhere
#define DISPLAY 1
#define PLAY 2
#define EXIT 3



/*
 Function: print_menu()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function prints the menu for the game
 Input parameters: None
 Returns: The menu
 Preconditions: None
 Postconditions: The manu is printed
*/
void print_menu(void);

/*
 Function: get_menu_choice()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function receives the menu choice an loops the menu if the choice is not valid
 Input parameters: the manu choice
 Returns: The menu if the result is not 1, 2, or 3. The program continues otherwise
 Preconditions: The menu choice must be given
 Postconditions: The menu is repeatedly printed until a valid input is entered
*/
int get_menu_choice(int menu_choice);

/*
 Function: print_game_rules()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function prints the game rules
 Input parameters: None
 Returns: The game rules
 Preconditions: None
 Postconditions: The game rules are printed
*/
void print_game_rules(void);

/*
 Function: roll_die()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function rolls six dice and puts them in a table
 Input parameters: The array that needs the dice values
 Returns: The numbers into the array
 Preconditions: An array muct be given
 Postconditions: The array is updated
*/
void roll_die(int table[]);

/*
 Function: print_array()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function prints the array
 Input parameters: The array with the dice values
 Returns: The numbers of the array
 Preconditions: An array must be given
 Postconditions: The array is printed
*/
void print_array(int list[]);

/*
 Function: rerolls()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function finds the dice that need to be rerolled, rolls them, and changes them
 Input parameters: The amount of dice the player wants to reroll and the dice rolls
 Returns: The updated values into the dice array
 Preconditions: An array muct be given and the amount of rerolls must be given
 Postconditions: The array is updated
*/
void rerolling(int rerolls, int list[]);

/*
 Function: print_scores()
 Date Created: 10/21/22
 Date Last Modified: 10/21/22
 Description: This function prints the scores of a player
 Input parameters: The score table and which player it is
 Returns: The scores
 Preconditions: The array and player must exist
 Postconditions: The scores are printed
*/
void print_scores(int scores[], int player);







/*
 Function: print_choices()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function prints the choices after someone has rolled
 Input parameters: All of the possible results
 Returns: The choices
 Preconditions: None
 Postconditions: The choices are printed
*/
void print_choices(int table[]);

/*
 Function: is_choice_valid()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function figures out if the choice the player makes is valid
 Input parameters: The player's input and their table of whetheror not they have already used a scoring
 Returns: If the choice is valid
 Preconditions: The choice and the table must exist
 Postconditions: The validity is returned (1 is invalid)
*/
int is_choice_valid(int choice, int is_done[]);

/*
 Function: process_choice_scoer()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out which function to call based on the input from the user
			It also will change the index of a table based on which one the player is using
 Input parameters: The player's input and their table of whether or not they have already used a scoring
 Returns: nothing
 Preconditions: The choice and the table must exist
 Postconditions: a function is called
 Maybe there is a much more efficient way to do this
 Sadly, my brain could not find it. I apologize if you read this
*/
void process_choice_score(int choice, int table[], int scores[], int dice[]);

/*
 Function: ones()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many ones the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void ones(int dice[], int score[]);

/*
 Function: twos()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many twos the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void twos(int dice[], int score[]);

/*
 Function: threes()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many threes the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void threes(int dice[], int score[]);

/*
 Function: fours()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many fours the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void fours(int dice[], int score[]);

/*
 Function: fives()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many fives the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void fives(int dice[], int score[]);

/*
 Function: sizex()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many sixes the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void sixes(int dice[], int score[]);

/*
 Function: three_of_a_kind()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out if there is three of a kind and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void three_of_a_kind(int dice[], int score[]);

/*
 Function: four_of_a_kind()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out if there is four of a kind and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void four_of_a_kind(int dice[], int score[]);

/*
 Function: fsmall_straight()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out if there is a small straight and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void small_straight(int dice[], int score[]);

/*
 Function: large_straight()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out if there is a large straight and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void large_straight(int dice[], int score[]);

/*
 Function: full_house()
 Date Created: 10/23/22
 Date Last Modified: 10/23/22
 Description: This function finds out if there is a full house and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void full_house(int dice[], int score[]);

/*
 Function: yahtzee()
 Date Created: 10/23/22
 Date Last Modified: 10/23/22
 Description: This function finds out if there is a yahtzee and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void yahtzee(int dice[], int score[]);

/*
 Function: chance()
 Date Created: 10/23/22
 Date Last Modified: 10/23/22
 Description: Calculates the score for a chance
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void chance(int dice[], int score[]);

/*
 Function: calculate_final_score()
 Date Created: 10/24/22
 Date Last Modified: 10/24/22
 Description: Calculates the total score
 Input parameters: The player's score table
 Returns: the score
 Preconditions: The table must exist
 Postconditions: the score is given
*/
int calculate_final_score(int scores[]);


#endif