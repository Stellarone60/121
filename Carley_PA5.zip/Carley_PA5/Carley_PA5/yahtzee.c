/*
Programmer name: Sarah Carley
Date made: 10/20/22
Date last modified: 10/21/22
Description: This is where all of the functions that make up the game will go
*/

#include "yahtzee.h"



/*
 Function: print_menu()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function prints the menu for the game
 Input parameters: None
 Returns: The menu
 Preconditions: None
 Postconditions: The manu is printed
*/
void print_menu(void)
{
	printf("1. Display rules\n");
	printf("2. Play Yahtzee.\n");
	printf("3. Exit.\n");
}

/*
 Function: get_menu_choice()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function receives the menu choice an loops the menu if the choice is not valid
 Input parameters: the manu choice
 Returns: The menu if the result is not 1, 2, or 3. The program continues otherwise
 Preconditions: The menu choice must be given
 Postconditions: The menu is repeatedly printed until a valid input is entered
*/
int get_menu_choice(int menu_choice)
{
	do
	{
		print_menu();
		scanf("%d", &menu_choice);
	} while (menu_choice > EXIT || menu_choice < DISPLAY);
	return menu_choice;
}

/*
 Function: print_game_rules()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function prints the game rules
 Input parameters: None
 Returns: The game rules
 Preconditions: None
 Postconditions: The game rules are printed
*/
void print_game_rules(void)
{
	printf("The scorecard used for Yahtzee is composed of two sections. A upper section and a lower section. A total of ");
	printf("thirteen boxes or thirteen scoring combinations are divided amongst the sections.The upper section consists of ");
	printf("boxes that are scored by summing the value of the dice matching the faces of the box.If a player rolls four 3's, then ");
	printf("the score placed in the 3's box is the sum of the dice which is 12. Once a player has chosen to score a box, it may not ");
	printf("be changed and the combination is no longer in play for future rounds.If the sum of the scores in the upper section is ");
	printf("greater than or equal to 63, then 35 more points are added to the players overall score as a bonus. A one player game ");
	printf("will consist of 13 turns while a 2 player game will consist of 26.\n");
}

/*
 Function: roll_die()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function rolls six dice and puts them in a table
 Input parameters: The array that needs the dice values
 Returns: The numbers into the array
 Preconditions: An array muct be given
 Postconditions: The array is updated
*/
void roll_die(int table[])
{
	int dice = 0, roll = 0;
	while (dice < 5)
	{
		roll = rand() % 6 + 1;
		table[dice] = roll;
		dice++;
	}
}

/*
 Function: print_array()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function prints the array
 Input parameters: The array with the dice values
 Returns: The numbers of the array
 Preconditions: An array must be given
 Postconditions: The array is printed
*/
void print_array(int list[])
{
	int index = 0, placeholder = 0;
	for (; index < 5; index++)
	{
		placeholder = index + 1;
		printf("Roll %d: %d\n", placeholder, list[index]);
	}
}


/*
 Function: rerolls()
 Date Created: 10/20/22
 Date Last Modified: 10/20/22
 Description: This function finds the dice that need to be rerolled, rolls them, and changes them
 Input parameters: The amount of dice the player wants to reroll and the dice rolls
 Returns: The updated values into the dice array
 Preconditions: An array muct be given and the amount of rerolls must be given
 Postconditions: The array is updated
*/
void rerolling(int rerolls, int list[])
{
	int index = 0, input = 0, loops = 0;
	while (loops < rerolls)
	{
		do
		{
			printf("Which dice would you like to reroll?\n");
			scanf("%d", &index);
			index--;
		} while (index < 0 || index > 4);
		input = rand() % 6 + 1;
		printf("The new roll is: %d\n", input);
		list[index] = input;
		++loops;
	}
}

/*
 Function: print_scores()
 Date Created: 10/21/22
 Date Last Modified: 10/22/22
 Description: This function prints the scores of a player
 Input parameters: The score table and which player it is
 Returns: The scores
 Preconditions: The array and player must exist
 Postconditions: The scores are printed
*/
void print_scores(int scores[], int player)
{
	int index = 1;
	printf("Player %d scores:\nOnes: %d\n", player, scores[index]);
	index++;
	printf("Twos: %d\n", scores[index]);
	index++;
	printf("Threes: %d\n", scores[index]);
	index++;
	printf("Fours: %d\n", scores[index]);
	index++;
	printf("Fives: %d\n", scores[index]);
	index++;
	printf("Sixes: %d\n", scores[index]);
	index++;
	printf("Three of a kind: %d\n", scores[index]);
	index++;
	printf("Four of a kind: %d\n", scores[index]);
	index++;
	printf("Small Straight: %d\n", scores[index]);
	index++;
	printf("Large straight: %d\n", scores[index]);
	index++;
	printf("Full house: %d\n", scores[index]);
	index++;
	printf("Yahtzee: %d\n", scores[index]);
	index++;
	printf("Chance: %d\n", scores[index]);
	index++;
}





/*
 Function: print_choices()
 Date Created: 10/20/22
 Date Last Modified: 10/22/22
 Description: This function prints the choices after someone has rolled
 Input parameters: All of the possible results
 Returns: The choices
 Preconditions: None
 Postconditions: The choices are printed
*/
void print_choices(int table[])
{
	int index = 1;
	printf("Make your choice below.\n");
	if (table[index] == 0)
	{
		printf("Ones: 1\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Twos: 2\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Threes: 3\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Fours: 4\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Fives: 5\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Sixes: 6\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Three of a kind: 7\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Four of a kind: 8\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Small straight: 9\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Large straight: 10\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Full House: 11\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Yahtzee: 12\n");
	}
	index++;
	if (table[index] == 0)
	{
		printf("Chance: 13\n");
	}
}

/*
 Function: is_choice_valid()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function figures out if the choice the player makes is valid
 Input parameters: The player's input and their table of whetheror not they have already used a scoring
 Returns: If the choice is valid
 Preconditions: The choice and the table must exist
 Postconditions: The validity is returned (1 is invalid)
*/
int is_choice_valid(int choice, int is_done[])
{
	int value = 0;
	if (is_done[choice] == 1)
	{
		printf("You have already used this. Please choose a valid number\n");
		value = 1;
	}
	//If the value is one, that means this choice is invalid.
	return value;
}

/*
 Function: process_choice_scoer()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out which function to call based on the input from the user
			It also will change the index of a table based on which one the player is using
 Input parameters: The player's input and their table of whether or not they have already used a scoring
 Returns: nothing
 Preconditions: The choice and the table must exist
 Postconditions: a function is called
 Maybe there is a much more efficient way to do this
 Sadly, my brain could not find it. I apologize if you read this
*/
void process_choice_score(int choice, int table[], int scores[], int dice[])
{
	if (choice == 1)
	{
		//Ones function call
		ones(dice, scores);
		table[1] = 1;
	}
	if (choice == 2)
	{
		//Twos function call
		twos(dice, scores);
		table[2] = 1;
	}
	if (choice == 3)
	{
		//threes function call
		threes(dice, scores);
		table[3] = 1;
	}
	if (choice == 4)
	{
		//fours function call
		fours(dice, scores);
		table[4] = 1;
	}
	if (choice == 5)
	{
		//fives funtion call
		fives(dice, scores);
		table[5] = 1;
	}
	if (choice == 6)
	{
		//sixes function call
		sixes(dice, scores);
		table[6] = 1;
	}
	if (choice == 7)
	{
		//three of a kind function call
		three_of_a_kind(dice, scores);
		table[7] = 1;
	}
	if (choice == 8)
	{
		//four of a kind function call
		four_of_a_kind(dice, scores);
		table[8] = 1;
	}
	if (choice == 9)
	{
		//small straight function call
		small_straight(dice, scores);
		table[9] = 1;
	}
	if (choice == 10)
	{
		//large straight function call
		large_straight(dice, scores);
		table[10] = 1;
	}
	if (choice == 11)
	{
		//full house function call
		full_house(dice, scores);
		table[11] = 1;
	}
	if (choice == 12)
	{
		//full house function call
		yahtzee(dice, scores);
		table[12] = 1;
	}
	if (choice == 13)
	{
		//chance function call
		chance(dice, scores);
		table[13] = 1;
	}
}


/*
 Function: ones()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many ones the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void ones(int dice[], int score[])
{
	int num_of_ones = 0, dice_index = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 1)
		{
			num_of_ones++;
		}
	}
	score[1] = num_of_ones * 1;
}

/*
 Function: twos()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many twos the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void twos(int dice[], int score[])
{
	int num_of_twos = 0, dice_index = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 2)
		{
			num_of_twos++;
		}
	}
	score[2] = num_of_twos * 2;
}

/*
 Function: threes()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many threes the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void threes(int dice[], int score[])
{
	int num_of_threes = 0, dice_index = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 3)
		{
			num_of_threes++;
		}
	}
	score[3] = num_of_threes * 3;
}

/*
 Function: fours()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many fours the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void fours(int dice[], int score[])
{
	int num_of_fours = 0, dice_index = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 4)
		{
			num_of_fours++;
		}
	}
	score[4] = num_of_fours * 4;
}

/*
 Function: fives()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many fives the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void fives(int dice[], int score[])
{
	int num_of_fives = 0, dice_index = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 5)
		{
			num_of_fives++;
		}
	}
	score[5] = num_of_fives * 5;
}

/*
 Function: sizex()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out how many sixes the players have and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void sixes(int dice[], int score[])
{
	int num_of_sixes = 0, dice_index = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 6)
		{
			num_of_sixes++;
		}
	}
	score[6] = num_of_sixes * 6;
}

/*
 Function: three_of_a_kind()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out if there is three of a kind and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void three_of_a_kind(int dice[], int score[])
{
	int three_kind = 0, dice_index = 0;
	int one = 0, two = 0, three = 0, four = 0, five = 0, six = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 1)
		{
			one++;
		}
		else if (dice[dice_index] == 2)
		{
			two++;
		}
		else if (dice[dice_index] == 3)
		{
			three++;
		}
		else if (dice[dice_index] == 4)
		{
			four++;
		}
		else if (dice[dice_index] == 5)
		{
			five++;
		}
		else if (dice[dice_index] == 6)
		{
			six++;
		}
	}
	if (one >= 3 || two >= 3 || three >= 3 || four >= 3 || five >= 3 || six >= 3)
	{
		three_kind = 1;
	}

	if (three_kind == 0)
	{
		score[7] = 0;
	}
	else
	{
		score[7] = dice[0] + dice[1] + dice[2] + dice[3] + dice[4];
	}
}

/*
 Function: four_of_a_kind()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out if there is four of a kind and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void four_of_a_kind(int dice[], int score[])
{
	int four_kind = 0, dice_index = 0;
	int one = 0, two = 0, three = 0, four = 0, five = 0, six = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 1)
		{
			one++;
		}
		else if (dice[dice_index] == 2)
		{
			two++;
		}
		else if (dice[dice_index] == 3)
		{
			three++;
		}
		else if (dice[dice_index] == 4)
		{
			four++;
		}
		else if (dice[dice_index] == 5)
		{
			five++;
		}
		else if (dice[dice_index] == 6)
		{
			six++;
		}
	}
	if (one >= 4 || two >= 4 || three >= 4 || four >= 4 || five >= 4 || six >= 4)
	{
		four_kind = 1;
	}

	if (four_kind == 0)
	{
		score[8] = 0;
	}
	else
	{
		score[8] = dice[0] + dice[1] + dice[2] + dice[3] + dice[4];
	}
}

/*
 Function: fsmall_straight()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out if there is a small straight and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void small_straight(int dice[], int score[])
{
	int sm_st = 0, dice_index = 0;
	int one = 0, two = 0, three = 0, four = 0, five = 0, six = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 1)
		{
			one++;
		}
		else if (dice[dice_index] == 2)
		{
			two++;
		}
		else if (dice[dice_index] == 3)
		{
			three++;
		}
		else if (dice[dice_index] == 4)
		{
			four++;
		}
		else if (dice[dice_index] == 5)
		{
			five++;
		}
		else if (dice[dice_index] == 6)
		{
			six++;
		}
	}
	if (one >= 1 && two >= 1 && three >= 1 && four >= 1)
	{
		sm_st = 1;
	}
	if (two >= 1 && three >= 1 && four >= 1 && five >= 1)
	{
		sm_st = 1;
	}
	if (three >= 1 && four >= 1 && five >= 1 && six >= 1)
	{
		sm_st = 1;
	}


	if (sm_st = 0)
	{
		score[9] = 0;
	}
	else
	{
		score[9] = 30;
	}
}

/*
 Function: large_straight()
 Date Created: 10/22/22
 Date Last Modified: 10/22/22
 Description: This function finds out if there is a large straight and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void large_straight(int dice[], int score[])
{
	int lg_st = 0, dice_index = 0;
	int one = 0, two = 0, three = 0, four = 0, five = 0, six = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 1)
		{
			one++;
		}
		else if (dice[dice_index] == 2)
		{
			two++;
		}
		else if (dice[dice_index] == 3)
		{
			three++;
		}
		else if (dice[dice_index] == 4)
		{
			four++;
		}
		else if (dice[dice_index] == 5)
		{
			five++;
		}
		else if (dice[dice_index] == 6)
		{
			six++;
		}
	}
	if (one >= 1 && two >= 1 && three >= 1 && four >= 1 && five >= 1)
	{
		lg_st = 1;
	}
	if (two >= 1 && three >= 1 && four >= 1 && five >= 1 && six >= 1)
	{
		lg_st = 1;
	}
	if (lg_st = 0)
	{
		score[10] = 0;
	}
	else
	{
		score[10] = 40;
	}
}

/*
 Function: full_house()
 Date Created: 10/23/22
 Date Last Modified: 10/23/22
 Description: This function finds out if there is a full house and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void full_house(int dice[], int score[])
{
	int dice_index = 0, pair = 0, triple = 0;
	int one = 0, two = 0, three = 0, four = 0, five = 0, six = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 1)
		{
			one++;
		}
		else if (dice[dice_index] == 2)
		{
			two++;
		}
		else if (dice[dice_index] == 3)
		{
			three++;
		}
		else if (dice[dice_index] == 4)
		{
			four++;
		}
		else if (dice[dice_index] == 5)
		{
			five++;
		}
		else if (dice[dice_index] == 6)
		{
			six++;
		}
	}
	if (one == 2 || two == 2 || three == 2 || four == 2 || five == 2 || six == 2)
	{
		pair = 1;
	}
	if (one == 3 || two == 3 || three == 3 || four == 3 || five == 3 || six == 3)
	{
		triple = 1;
	}
	if (pair == 1 && triple == 1)
	{
		score[11] = 25;
	}
	else
	{
		score[11] = 0;
	}
}

/*
 Function: yahtzee()
 Date Created: 10/23/22
 Date Last Modified: 10/23/22
 Description: This function finds out if there is a yahtzee and calculates the score
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void yahtzee(int dice[], int score[])
{
	int dice_index = 0;
	int one = 0, two = 0, three = 0, four = 0, five = 0, six = 0;
	for (; dice_index < 5; dice_index++)
	{
		if (dice[dice_index] == 1)
		{
			one++;
		}
		else if (dice[dice_index] == 2)
		{
			two++;
		}
		else if (dice[dice_index] == 3)
		{
			three++;
		}
		else if (dice[dice_index] == 4)
		{
			four++;
		}
		else if (dice[dice_index] == 5)
		{
			five++;
		}
		else if (dice[dice_index] == 6)
		{
			six++;
		}
	}
	if (one == 5 || two == 5 || three == 5 || four == 5 || five == 5 || six == 5)
	{
		score[12] = 50;
	}
	else
	{
		score[12] = 0;
	}
}

/*
 Function: chance()
 Date Created: 10/23/22
 Date Last Modified: 10/23/22
 Description: Calculates the score for a chance
 Input parameters: The dice table and the player's score table
 Returns: nothing
 Preconditions: The tables
 Postconditions: the score is given
*/
void chance(int dice[], int score[])
{
	score[13] = dice[0] + dice[1] + dice[2] + dice[3] + dice[4];
}

/*
 Function: calculate_final_score()
 Date Created: 10/24/22
 Date Last Modified: 10/24/22
 Description: Calculates the total score
 Input parameters: The player's score table
 Returns: the score
 Preconditions: The table must exist
 Postconditions: the score is given
*/
int calculate_final_score(int scores[])
{
	int total_score = 0, index = 1;
	if ((scores[1] + scores[2] + scores[3] + scores[4] + scores[5]) >= 63)
	{
		total_score += 63;
	}
	for (; index < 14; index++)
	{
		total_score = total_score + scores[index];
	}
	return total_score;
}