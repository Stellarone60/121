/*
Programmer name: Sarah Carley
Date made: 10/29/22
Date last modified: 10/30/22
Description: This is the header where funtions will be initialized and libraries defined
*/

#ifndef BATTLESHIP_H

#define BATTLESHIP_H

#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>//Standard library
#include<time.h>//Keeps srand actually random
#include<math.h>//Math functions, probably won't need them but just in case
#include<stdlib.h>//gets the random
#include<string.h>

//Makes constants for the max rows and max columns
#define MAX_ROWS 10
#define MAX_COLS 10


typedef struct stats
{
	int hits;
	int misses;
	int total_shots;
	double ratio;
}Stats;


/*
 Function: set_void_board()
 Date Created: 10/29/22
 Date Last Modified: 10/29/22
 Description: This function sets all boards to rows and columns of - before anything else is set
 Input parameters: the board, number of columns, and number of rows in the board
 Returns: a full board
 Preconditions: the board must exist
 Postconditions: The board is updated
*/
void set_void_board(char board[MAX_ROWS][MAX_COLS], int max_rows, int max_cols);

/*
 Function: print_boar()
 Date Created: 10/29/22
 Date Last Modified: 10/29/22
 Description: This function prints the board
 Input parameters: the board, number of columns, and number of rows in the board
 Returns: a full board
 Preconditions: the board must exist
 Postconditions: The board is printed
*/
void print_board(char board[][MAX_COLS], int max_rows, int max_cols);

/*
 Function: welcome_screen()
 Date Created: 10/30/22
 Date Last Modified: 10/30/22
 Description: This function prints the rules and a welcome message
 Input parameters: none
 Returns: the rules
 Preconditions: none
 Postconditions: The rules and welcome message are printed
*/
void welcome_screen(void);

/*
 Function: manual_placing()
 Date Created: 10/30/22
 Date Last Modified: 10/30/22
 Description: This function gets the player to manually place their ships
 Input parameters: the player's board, the table for placing
 Returns: the updated board
 Preconditions: the tables must exist
 Postconditions: The board is updated
*/
void manual_placing(char board[][MAX_COLS], int placing[10], int max_rows, int max_cols);

/*
 Function: choose_player()
 Date Created: 10/30/22
 Date Last Modified: 10/30/22
 Description: This function figures out which player will go first
 Input parameters: none
 Returns: the player that goes first
 Preconditions: none
 Postconditions: The player is returned
*/
int choose_player(void);

/*
 Function: computer_placing()
 Date Created: 10/31/22
 Date Last Modified: 10/31/22
 Description: This function places ships onto the board at random
 Input parameters: the player's board
 Returns: the updated board
 Preconditions: the table must exist
 Postconditions: The board is updated
*/
void computer_placing(char board[][MAX_COLS]);

/*
 Function: if_hit()
 Date Created: 10/31/22
 Date Last Modified: 11/6/22
 Description: This function figures out if it is a hit or a miss
 Input parameters: the opponent's board, player 2's board visual, and the current player, the inputted cell, the log file,
					the ship pointers, the player's hits and misses
 Returns: nothing
 Preconditions: the tables and player must exist
 Postconditions: it isprinted to the outfile if it is a hit or miss and if a ship was sunk
*/
int if_hit(int cell, int player, char opponent_board[][MAX_COLS], char opponent_board_visual[][MAX_COLS], FILE* log,
	int* cruiser, int* battleship, int* carrier, int* sub, int* destroyer, int* hits, int* misses, int adder);

/*
 Function: insert_stats()
 Date Created: 11/5/22
 Date Last Modified: 11/6/22
 Description: This function puts stats into a struct
 Input parameters: the struct, the hits and misses of the player
 Returns: nothing
 Preconditions: the everything must exist
 Postconditions: the struct is made
*/
void insert_stats(Stats* player, int hits, int misses);







#endif