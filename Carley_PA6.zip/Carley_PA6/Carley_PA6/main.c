/*
Programmer name: Sarah Carley
Date made: 10/29/22
Date last modified: 10/31/22
Description: This is the main function where the functions will all be called in a certain order to run the game
*/

#include "battleship.h"

int main(void)
{
	char p1_board[10][10] = { '\0' }, p2_board[10][10] = { '\0' }, p2_board_visual[10][10] = { '\0' };
	FILE* outfile = fopen("battleship.log", "w");
	int winner = 0, set_up = 0, placing[10] = { 0 }, num = 0, player = 0, loser = 0;
	int game_over = 0, cell = 0, hit = 0, row = 0, column = 0;
	int player1_hits = 0, player2_hits = 0, adder = 0;
	int* p1_carrier = 0, * p1_battleship = 0, * p1_cruiser = 0, * p1_sub = 0, * p1_destroyer = 0, *p1_hits = 0, *p1_misses = 0;
	int* p2_carrier = 0, * p2_battleship = 0, * p2_cruiser = 0, * p2_sub = 0, * p2_destroyer = 0, *p2_hits = 0, *p2_misses = 0;

	//Keeps the number rolls actually random
	srand((unsigned int)time(NULL));

	//Sets the boards to '~' for all cells
	set_void_board(p1_board, MAX_ROWS, MAX_COLS);
	set_void_board(p2_board, MAX_ROWS, MAX_COLS);
	set_void_board(p2_board_visual, MAX_ROWS, MAX_COLS);
	//prints the welcome screen
	welcome_screen();
	//pauses then clears the screen
	system("pause");
	system("cls");
	//Gets whether or not the player wants to enter their ships manually or not
	do
	{
		printf("Would you like to:\n1: Enter locations of ships manually\n2: Have the computer enter the locations of the ships\n");
		scanf("%d", &set_up);
	} while (set_up < 1 || set_up > 2);
	//Sees if the player wants to set up manually
	if (set_up == 1)
	{
		//Call the function to manually place ships
		manual_placing(p1_board, placing, 10, 10);
	}
	else
	{
		//Call the function to randomly place ships
		computer_placing(p1_board);
		//Print the board
		print_board(p1_board, 10, 10);
	}
	//Sets the second player's board
	computer_placing(p2_board);
	//Randomly chooses the first player
	player = choose_player();
	system("pause");
	system("cls");
	while (game_over == 0)
	{
		if (p1_carrier >= 5 && p1_battleship >= 4 && p1_cruiser >= 3 && p1_sub >= 3 && p1_destroyer >= 2)
		{
			game_over = 1;
			winner = 2;
			loser = 1;
		}
		else if (p2_carrier >= 5 && p2_battleship >= 4 && p2_cruiser >= 3 && p2_sub >= 3 && p2_destroyer >= 2)
		{
			game_over = 1;
			winner = 1;
			loser = 2;
		}
		else
		{


			printf("Player %d\n", player);
			//Checks which player it is to see if the coordinates need to be asked or not
			if (player == 1)
			{
				//Shows the hits and misses on the other player's board
				printf("What you know of player 2's board:\n");
				print_board(p2_board_visual, 10, 10);
				//Prompts the user or a cell and then gets the cell
				do
				{
					printf("Please enter the cell you want to try and hit (one you have not hit before).\n");
					scanf("%d", &cell);
					column = cell % 10;
					row = cell / 10;
				} while (p2_board_visual[row][column] == 'm' || p2_board_visual[row][column] == '*');
				
				adder = if_hit(cell, player, p2_board, p2_board_visual, outfile, &p2_cruiser, &p2_battleship, &p2_carrier, &p2_sub, &p2_destroyer, &p1_hits, &p1_misses, adder);
				player1_hits += adder;
			}
			else
			{
				adder = if_hit(cell, player, p1_board, p2_board_visual, outfile, &p1_cruiser, &p1_battleship, &p1_carrier, &p1_sub, &p1_destroyer, &p2_hits, &p2_misses, adder);
				print_board(p1_board, 10, 10);
				player2_hits += adder;
			}


			if (player == 1)
			{
				player = 2;
			}
			else
			{
				player = 1;
			}
			system("pause");
			system("cls");
		}
	}


	printf("The winner is player %d!\n", winner);
	fprintf(outfile, "The winner is player %d and the loser is player %d\n\n\n", winner, loser);
	Stats p1;
	Stats p2;
	insert_stats(&p1, player1_hits, p1_misses);
	insert_stats(&p2, player2_hits, p2_misses);

	
	

	fprintf(outfile, "~~~ Player 1 stats ~~~\nHits: %d\nMisses: %d\nTotal shots: %d\nHit/miss ratio: %.0lf\n\n\n", p1.hits, p1.misses, p1.total_shots, p1.ratio);
	fprintf(outfile, "~~~ Player 2 stats ~~~\nHits: %d\nMisses: %d\nTotal shots: %d\nHit/miss ratio: %.0lf", p2.hits, p2.misses, p2.total_shots, p2.ratio);

	system("pause");
	system("cls");
	printf("DON'T FORGET TO SUBMIT YOU IDIOT!!");
	return 0;
}