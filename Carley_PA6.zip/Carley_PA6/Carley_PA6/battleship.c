/*
Programmer name: Sarah Carley
Date made: 10/29/22
Date last modified: 10/31/22
Description: This is where all of the functions that make up the game will go
*/

#include "battleship.h"



/*
 Function: set_void_board()
 Date Created: 10/29/22
 Date Last Modified: 10/29/22
 Description: This function sets all boards to rows and columns of - before anything else is set
 Input parameters: the board, number of columns, and number of rows in the board
 Returns: a full board
 Preconditions: the board must exist
 Postconditions: The board is updated
*/
void set_void_board(char board[MAX_ROWS][MAX_COLS], int max_rows, int max_cols)
{
	int row_index = 0, col_index = 0;
	for (col_index = 0; row_index < max_rows; row_index++)
	{
		for (; col_index < max_cols; col_index++)
		{
			board[row_index][col_index] = '~';
		}
		col_index = 0;
	}
}

/*
 Function: print_board()
 Date Created: 10/29/22
 Date Last Modified: 10/29/22
 Description: This function prints the board
 Input parameters: the board, number of columns, and number of rows in the board
 Returns: a full board
 Preconditions: the board must exist
 Postconditions: The board is printed
*/
void print_board(char board[][MAX_COLS], int max_rows, int max_cols)
{
	int row = 0, col = 0;
	printf("   0 1 2 3 4 5 6 7 8 9\n");
	for (char col = 0; row < max_rows; row++)
	{
		printf("%d  ", row);
		// inner loop for column
		for (char col = 0; col < max_cols; col++)
		{
			printf("%c ", board[row][col]);
		}
		printf("\n"); // new line
	}
}

/*
 Function: welcome_screen()
 Date Created: 10/30/22
 Date Last Modified: 10/30/22
 Description: This function prints the rules and a welcome message
 Input parameters: none
 Returns: the rules
 Preconditions: none
 Postconditions: The rules and welcome message are printed
*/
void welcome_screen(void)
{
	printf("Welcome to Battleship! In this game you will place different boatson your board. Your board is 10 by 10 cells.");
	printf(" Once placed, you will try to guess which cells your opponent's boats are in. Once all ships on one side are destroyed, ");
	printf("The remaining player wins! Player 1 is you and player 2 is the computer!\n");
}

/*
 Function: manual_placing()
 Date Created: 10/30/22
 Date Last Modified: 10/30/22
 Description: This function gets the player to manually place their ships
 Input parameters: the player's board, the table for placing
 Returns: the updated board
 Preconditions: the tables must exist
 Postconditions: The board is updated
*/
void manual_placing(char board[][MAX_COLS], int placing[10], int max_rows, int max_cols)
{
	int row = 0, col = 0, setting = 0, input = 0, index = 9, loops = 0, ah = 1;
	print_board(board, 10, 10);
	while (ah < 6)
	{
		printf("Please enter the cell %d you want the carrier to be in. All other steps will allow you to put all cells in at once:\n", ah);
		scanf("%d", &input);
		loops = 0;
		while (loops < 2)
		{
			placing[index - loops] = input % 10;
			input = input / 10;
			loops++;
		}
		index -= 2;
		ah++;
	}
	loops = 0;
	while (loops < 5)
	{
		row = placing[0 + setting];
		col = placing[1 + setting];
		board[row][col] = 'c';
		setting += 2;
		loops++;
	}
	print_board(board, 10, 10);


	row = 0, col = 0, setting = 0, input = 0, index = 7, loops = 0;
	printf("Please enter the four cells you want the battleship to be in:\n");
	scanf("%d", &input);
	while (loops < 10)
	{
		placing[index - loops] = input % 10;
		input = input / 10;
		loops++;
	}
	loops = 0;
	while (loops < 5)
	{
		row = placing[0 + setting];
		col = placing[1 + setting];
		board[row][col] = 'b';
		setting += 2;
		loops++;
	}
	print_board(board, 10, 10);


	row = 0, col = 0, setting = 0, input = 0, index = 5, loops = 0;
	printf("Please enter the three cells you want the cruiser to be in:\n");
	scanf("%d", &input);
	while (loops < 6)
	{
		placing[index - loops] = input % 10;
		input = input / 10;
		loops++;
	}
	loops = 0;
	while (loops < 3)
	{
		row = placing[0 + setting];
		col = placing[1 + setting];
		board[row][col] = 'r';
		setting += 2;
		loops++;
	}
	print_board(board, 10, 10);

	row = 0, col = 0, setting = 0, input = 0, index = 5, loops = 0;
	printf("Please enter the three cells you want the sub to be in:\n");
	scanf("%d", &input);
	while (loops < 6)
	{
		placing[index - loops] = input % 10;
		input = input / 10;
		loops++;
	}
	loops = 0;
	while (loops < 3)
	{
		row = placing[0 + setting];
		col = placing[1 + setting];
		board[row][col] = 's';
		setting += 2;
		loops++;
	}
	print_board(board, 10, 10);


	row = 0, col = 0, setting = 0, input = 0, index = 3, loops = 0;
	printf("Please enter the two cells you want the destroyer to be in:\n");
	scanf("%d", &input);
	while (loops < 4)
	{
		placing[index - loops] = input % 10;
		input = input / 10;
		loops++;
	}
	loops = 0;
	while (loops < 2)
	{
		row = placing[0 + setting];
		col = placing[1 + setting];
		board[row][col] = 'd';
		setting += 2;
		loops++;
	}
	print_board(board, 10, 10);
}

/*
 Function: choose_player()
 Date Created: 10/30/22
 Date Last Modified: 10/30/22
 Description: This function figures out which player will go first
 Input parameters: none
 Returns: the player that goes first
 Preconditions: none
 Postconditions: The player is returned
*/
int choose_player(void)
{
	int num = 0;
	num = rand() % 2 + 1;
	printf("Player %d is first\n", num);
	return num;
}

/*
 Function: computer_placing()
 Date Created: 10/31/22
 Date Last Modified: 10/31/22
 Description: This function places ships onto the board at random
 Input parameters: the player's board
 Returns: the updated board
 Preconditions: the table must exist
 Postconditions: The board is updated
*/
void computer_placing(char board[][MAX_COLS])
{
	//For direction: 1 = up, 2 = down, 3 = left, 4 = right
	int column = 0, row = 0, direction = 0, after_direction_cols = 0, after_direction_rows = 0, after_direction = 0, loops = 0;
	//Carrier
	column = rand() % 9 + 1;
	column -= 1;
	row = rand() % 9 + 1;
	row -= 1;
	while (after_direction == 0)
	{
		direction = rand() % 4 + 1;
		if (column <= 5 && direction == 4)
		{
			after_direction_cols = 1;
		}
		if (column >= 4 && direction == 3)
		{
			after_direction_cols = 1;
		}
		if (row <= 5 && direction == 2)
		{
			after_direction_rows = 1;
		}
		if (row >= 4 && direction == 1)
		{
			after_direction_rows = 1;
		}
		if (after_direction_rows == 1 || after_direction_cols == 1)
		{
			after_direction = 1;
		}
	}
	if (direction == 1)
	{
		while (loops < 5)
		{
			board[row - loops][column] = 'c';
			loops++;
		}
	}
	else if (direction == 2)
	{
		while (loops < 5)
		{
			board[row + loops][column] = 'c';
			loops++;
		}
	}
	else if (direction == 3)
	{
		while (loops < 5)
		{
			board[row][column - loops] = 'c';
			loops++;
		}
	}
	else if (direction == 4)
	{
		while (loops < 5)
		{
			board[row][column + loops] = 'c';
			loops++;
		}
	}



	//Battleship
	after_direction_cols = 0, after_direction_rows = 0, after_direction = 0, loops = 0;
	do
	{
		column = rand() % 9 + 1;
		column -= 1;
		row = rand() % 9 + 1;
		row -= 1;
	} while (board[row][column] != '~');
	while (after_direction == 0)
	{
		direction = rand() % 4 + 1;
		if (column <= 6 && direction == 4)
		{
			if (board[row][column + 1] != '~' || board[row][column + 2] != '~' || board[row][column + 3] != '~')
			{
				after_direction_cols = 0;
			}
			else
			{
				after_direction_cols = 1;
			}
			
		}
		if (column >= 3 && direction == 3)
		{
			if (board[row][column - 1] != '~' || board[row][column - 2] != '~' || board[row][column - 3] != '~')
			{
				after_direction_cols = 0;
			}
			else
			{
				after_direction_cols = 1;
			}
		}
		if (row <= 6 && direction == 2)
		{
			if (board[row + 1][column] != '~' || board[row + 2][column] != '~' || board[row + 3][column] != '~')
			{
				after_direction_rows = 0;
			}
			else
			{
				after_direction_rows = 1;
			}
		}
		if (row >= 3 && direction == 1)
		{
			if (board[row - 1][column] != '~' || board[row - 2][column] != '~' || board[row - 3][column] != '~')
			{
				after_direction_rows = 0;
			}
			else
			{
				after_direction_rows = 1;
			}
		}
		if (after_direction_rows == 1 || after_direction_cols == 1)
		{
			after_direction = 1;
		}
	}
	if (direction == 1)
	{
		while (loops < 4)
		{
			board[row - loops][column] = 'b';
			loops++;
		}
	}
	else if (direction == 2)
	{
		while (loops < 4)
		{
			board[row + loops][column] = 'b';
			loops++;
		}
	}
	else if (direction == 3)
	{
		while (loops < 4)
		{
			board[row][column - loops] = 'b';
			loops++;
		}
	}
	else if (direction == 4)
	{
		while (loops < 4)
		{
			board[row][column + loops] = 'b';
			loops++;
		}
	}


	//Cruiser
	after_direction_cols = 0, after_direction_rows = 0, after_direction = 0, loops = 0;
	do
	{
		column = rand() % 9 + 1;
		column -= 1;
		row = rand() % 9 + 1;
		row -= 1;
	} while (board[row][column] != '~');
	while (after_direction == 0)
	{
		direction = rand() % 4 + 1;
		if (column <= 7 && direction == 4)
		{
			if (board[row][column + 1] != '~' || board[row][column + 2] != '~')
			{
				after_direction_cols = 0;
			}
			else
			{
				after_direction_cols = 1;
			}
		}
		if (column >= 2 && direction == 3)
		{
			if (board[row][column - 1] != '~' || board[row][column - 2] != '~')
			{
				after_direction_cols = 0;
			}
			else
			{
				after_direction_cols = 1;
			}
		}
		if (row <= 7 && direction == 2)
		{
			if (board[row + 1][column] != '~' || board[row + 2][column] != '~')
			{
				after_direction_rows = 0;
			}
			else
			{
				after_direction_rows = 1;
			}
		}
		if (row >= 2 && direction == 1)
		{
			if (board[row - 1][column] != '~' || board[row - 2][column] != '~')
			{
				after_direction_rows = 0;
			}
			else
			{
				after_direction_rows = 1;
			}
		}
		if (after_direction_rows == 1 || after_direction_cols == 1)
		{
			after_direction = 1;
		}
	}
	if (direction == 1)
	{
		while (loops < 3)
		{
			board[row - loops][column] = 'r';
			loops++;
		}
	}
	else if (direction == 2)
	{
		while (loops < 3)
		{
			board[row + loops][column] = 'r';
			loops++;
		}
	}
	else if (direction == 3)
	{
		while (loops < 3)
		{
			board[row][column - loops] = 'r';
			loops++;
		}
	}
	else if (direction == 4)
	{
		while (loops < 3)
		{
			board[row][column + loops] = 'r';
			loops++;
		}
	}



	//Sub
	after_direction_cols = 0, after_direction_rows = 0, after_direction = 0, loops = 0;
	do
	{
		column = rand() % 9 + 1;
		column -= 1;
		row = rand() % 9 + 1;
		row -= 1;
	} while (board[row][column] != '~');
	while (after_direction == 0)
	{
		direction = rand() % 4 + 1;
		if (column <= 7 && direction == 4)
		{
			if (board[row][column + 1] != '~' || board[row][column + 2] != '~')
			{
				after_direction_cols = 0;
			}
			else
			{
				after_direction_cols = 1;
			}
		}
		if (column >= 2 && direction == 3)
		{
			if (board[row][column - 1] != '~' || board[row][column - 2] != '~')
			{
				after_direction_cols = 0;
			}
			else
			{
				after_direction_cols = 1;
			}
		}
		if (row <= 7 && direction == 2)
		{
			if (board[row + 1][column] != '~' || board[row + 2][column] != '~')
			{
				after_direction_rows = 0;
			}
			else
			{
				after_direction_rows = 1;
			}
		}
		if (row >= 2 && direction == 1)
		{
			if (board[row - 1][column] != '~' || board[row - 2][column] != '~')
			{
				after_direction_rows = 0;
			}
			else
			{
				after_direction_rows = 1;
			}
		}
		if (after_direction_rows == 1 || after_direction_cols == 1)
		{
			after_direction = 1;
		}
	}
	if (direction == 1)
	{
		while (loops < 3)
		{
			board[row - loops][column] = 's';
			loops++;
		}
	}
	else if (direction == 2)
	{
		while (loops < 3)
		{
			board[row + loops][column] = 's';
			loops++;
		}
	}
	else if (direction == 3)
	{
		while (loops < 3)
		{
			board[row][column - loops] = 's';
			loops++;
		}
	}
	else if (direction == 4)
	{
		while (loops < 3)
		{
			board[row][column + loops] = 's';
			loops++;
		}
	}



	//Destroyer
	after_direction_cols = 0, after_direction_rows = 0, after_direction = 0, loops = 0;
	do
	{
		column = rand() % 9 + 1;
		column -= 1;
		row = rand() % 9 + 1;
		row -= 1;
	} while (board[row][column] != '~');
	while (after_direction == 0)
	{
		direction = rand() % 4 + 1;
		if (column <= 8 && direction == 4)
		{
			if (board[row][column + 1] != '~')
			{
				after_direction_cols = 0;
			}
			else
			{
				after_direction_cols = 1;
			}
		}
		if (column >= 1 && direction == 3)
		{
			if (board[row][column - 1] != '~')
			{
				after_direction_cols = 0;
			}
			else
			{
				after_direction_cols = 1;
			}
		}
		if (row <= 8 && direction == 2)
		{
			if (board[row + 1][column] != '~')
			{
				after_direction_rows = 0;
			}
			else
			{
				after_direction_rows = 1;
			}
		}
		if (row >= 1 && direction == 1)
		{
			if (board[row - 1][column] != '~')
			{
				after_direction_rows = 0;
			}
			else
			{
				after_direction_rows = 1;
			}
		}
		if (after_direction_rows == 1 || after_direction_cols == 1)
		{
			after_direction = 1;
		}
	}
	if (direction == 1)
	{
		while (loops < 2)
		{
			board[row - loops][column] = 'd';
			loops++;
		}
	}
	else if (direction == 2)
	{
		while (loops < 2)
		{
			board[row + loops][column] = 'd';
			loops++;
		}
	}
	else if (direction == 3)
	{
		while (loops < 2)
		{
			board[row][column - loops] = 'd';
			loops++;
		}
	}
	else if (direction == 4)
	{
		while (loops < 2)
		{
			board[row][column + loops] = 'd';
			loops++;
		}
	}
}

/*
 Function: if_hit()
 Date Created: 10/31/22
 Date Last Modified: 11/6/22
 Description: This function figures out if it is a hit or a miss
 Input parameters: the opponent's board, player 2's board visual, and the current player, the inputted cell, the log file,
					the ship pointers, the player's hits and misses
 Returns: nothing
 Preconditions: the tables and player must exist
 Postconditions: it isprinted to the outfile if it is a hit or miss and if a ship was sunk
*/
int if_hit(int cell, int player, char opponent_board[][MAX_COLS], char opponent_board_visual[][MAX_COLS], FILE* log,
	int* cruiser, int* battleship, int* carrier, int* sub, int* destroyer, int* hits, int* misses, int adder)
{
	int row = 0, column = 0, temp_cell = 0, sunken_ship = 0, hit = 0;
	char sunk[11] = "";
	if (player == 1)
	{
		column = cell % 10;
		temp_cell = cell / 10;
		row = temp_cell;
		printf("Row: %d\nColumn: %d\n", row, column);
		if (opponent_board[row][column] != '~')
		{
			hit++;
			//Checks if the carrier was hit
			if (opponent_board[row][column] == 'c')
			{
				//increments the pointer
				*carrier+=1;
				if (*carrier == 5)
				{
					sunken_ship = 1;
					strcpy(sunk, "carrier");
					printf("Player 2's carrier has been sunk!\n");
				}
			}
			//Checks if the battleship was hit
			else if (opponent_board[row][column] == 'b')
			{
				//increments the pointer
				*battleship+=1;
				if (*battleship == 4)
				{
					sunken_ship = 1;
					strcpy(sunk, "battleship");
					printf("Player 2's battleship has been sunk!\n");
				}
			}
			//Checks if the cruiser was hit
			else if (opponent_board[row][column] == 'r')
			{
				//increments the pointer
				*cruiser+=1;
				if (*cruiser == 3)
				{
					sunken_ship = 1;
					strcpy(sunk, "cruiser");
					printf("Player 2's cruiser has been sunk!\n");
				}
			}
			//Checks if the sub was hit
			else if (opponent_board[row][column] == 's')
			{
				//increments the pointer
				*sub+=1;
				if (*sub == 3)
				{
					sunken_ship = 1;
					strcpy(sunk, "sub");
					printf("Player 2's sub has been sunk!\n");
				}
			}
			//Checks if the destroyer was hit
			else if (opponent_board[row][column] == 'd')
			{
				//increments the pointer
				*destroyer+=1;
				if (*destroyer == 2)
				{
					sunken_ship = 1;
					strcpy(sunk, "destroyer");
					printf("Player 2's destroyer has been sunk!\n");
				}
			}



			//Says if it was a hit
			printf("It's a hit!\n");
			//Changes the opponent's board visual
			opponent_board_visual[row][column] = '*';
			//Also changes the opponent's board
			opponent_board[row][column] = '*';
			//Logs the hit into the log
			fprintf(log, "Player %d: %d  \"hit\"\n", player, cell);
			if (sunken_ship == 1)
			{
				fprintf(log, "Sunk %s!\n", sunk);
			}
			sunken_ship = 0;
		}
		else
		{
			*misses = *misses+1;
			//This says it is missed
			printf("Miss!\n");
			//This changes the opponent's board visual to m in the cell that was hit
			opponent_board_visual[row][column] = 'm';
			//This logs the move into the log
			fprintf(log, "Player %d: %d  \"miss\"\n", player, cell);
		}
	}
	else
	{
		column = rand() % 9 + 1;
		column -= 1;
		row = rand() % 9 + 1;
		row -= 1;
		printf("Row: %d\nColumn: %d\n", row, column);

		

		if (opponent_board[row][column] != '~')
		{
			hit++;
			//Checks if the carrier was hit
			if (opponent_board[row][column] == 'c')
			{
				//increments the pointer
				*carrier += 1;
				if (*carrier == 5)
				{
					sunken_ship = 1;
					strcpy(sunk, "carrier");
					printf("Player 1's carrier has been sunk!\n");
				}
			}
			//Checks if the battleship was hit
			else if (opponent_board[row][column] == 'b')
			{
				//increments the pointer
				*battleship += 1;
				if (*battleship == 4)
				{
					sunken_ship = 1;
					strcpy(sunk, "battleship");
					printf("Player 1's battleship has been sunk!\n");
				}
			}
			//Checks if the cruiser was hit
			else if (opponent_board[row][column] == 'r')
			{
				//increments the pointer
				*cruiser += 1;
				if (*cruiser == 3)
				{
					sunken_ship = 1;
					strcpy(sunk, "cruiser");
					printf("Player 1's cruiser has been sunk!\n");
				}
			}
			//Checks if the sub was hit
			else if (opponent_board[row][column] == 's')
			{
				//increments the pointer
				*sub += 1;
				if (*sub == 3)
				{
					sunken_ship = 1;
					strcpy(sunk, "sub");
					printf("Player 1's sub has been sunk!\n");
				}
			}
			//Checks if the destroyer was hit
			else if (opponent_board[row][column] == 'd')
			{
				//increments the pointer
				*destroyer += 1;
				if (*destroyer == 2)
				{
					sunken_ship = 1;
					strcpy(sunk, "destroyer");
					printf("Player 1's destroyer has been sunk!\n");
				}
			}




			printf("It's a hit!\n");
			opponent_board[row][column] = '*';
			fprintf(log, "Player %d: %d%d  \"hit\"\n", player, row, column);

			if (sunken_ship == 1)
			{
				fprintf(log, "Sunk %s!\n", sunk);
			}
			sunken_ship = 0;
		}
		else
		{
			*misses = *misses+1;
			printf("Miss!\n");
			opponent_board[row][column] = 'm';
			fprintf(log, "Player %d: %d%d  \"miss\"\n", player, row, column);
		}
	}
	return hit;
}

/*
 Function: insert_stats()
 Date Created: 11/5/22
 Date Last Modified: 11/6/22
 Description: This function puts stats into a struct
 Input parameters: the struct, the hits and misses of the player
 Returns: nothing
 Preconditions: the everything must exist
 Postconditions: the struct is made
*/
void insert_stats(Stats* player, int hits, int misses)
{
	int total = 0;
	double ratio = 0;
	double hit = 0, miss = 0;
	total = hits + misses;
	hit = hits * 100.0;
	miss = misses * 100.0;
	ratio = (hit / miss)*100;
	(*player).hits = hits;
	(*player).misses = misses;
	(*player).total_shots = total;
	(*player).ratio = ratio;
}