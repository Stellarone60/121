/*
Programmer name: Sarah Carley
Date made: 11/29/22
Date last modified: 11/29/22
Description: This is the main function where all the program will be based
*/

#include "header.h"


int main(void)
{
	//str_n_cat
	//Sets the strings
	char str_cat[20] = "hi ", source[6] = "there";
	//I have no idea why it keeps giving a demonic character instead of an h and didn't have enough time to find out
	//Puts the strings in the function
	*str_cat = my_str_n_cat(str_cat, source, 6);
	//Prints the modified string
	puts(str_cat);


	//binary search
	printf("\n\n");
	//Sets the values
	int int_arr[10] = { 1,3,4,5,7,8,9,22,44,56 }, index = 0, target = 4;
	//Finds the target and sets the index
	index = binary_search(int_arr, 10, target);
	//Prints the result
	printf("The index where %d can be found is %d\n", target, index);
	

	//bubble sort
	printf("\n\n");
	//sets the values
	char* str1 = "green", * str2 = "Purple", * str3 = "red", * str4 = "orange";
	char* arr_strs[4] = {"green", "Purple", "red", "ORANGE"};
	int loops = 0;
	//Prints off the strings beforehand
	while (loops < 4)
	{
		printf("%s\n", arr_strs[loops]);
		loops++;
	}
	//Sorts the strings
	bubble_sort(arr_strs, 4);
	//Prints the new array of pointers to strings
	printf("After bubble sort:\n");
	loops = 0;
	while (loops < 4)
	{
		printf("%s\n", arr_strs[loops]);
		loops++;
	}


	printf("\n\n");
	//revursive is palindrome
	//Sets the string and ints
	char* pal_str = "tacocat";
	int size = 7, palin = 0;
	//Runs the string through the function
	palin = is_palindrome(pal_str, size);
	//if it is a palindrome
	if (palin == 1)
	{
		//Print that is ia a palindrome
		printf("%s is a palindrome", pal_str);
	}
	//If it is not a plaindrome
	else
	{
		//print that it is not
		printf("%s is not a palindrome", pal_str);
	}


	
	printf("\n\n");
	//recursive sum of primes
	//Sets the variables
	int prime = 11, sum_of_primes = 0;
	//Gets the sum
	sum_of_primes = sum_primes(prime);
	//Prints the result
	printf("The sum of primes before and to %d is %d", prime, sum_of_primes);




	printf("\n\n");
	//Maximum occurrences
	//sets the variables
	char* test_str = "strings";
	int* occurrences = 0;
	char* pointer = '\0';
	Occurrences table[20];
	//Puts the variables through the function
	maximum_occurrences(test_str, &table, &occurrences, &pointer);
	//Prints the result
	printf("In the string %s, %c is the most commonly occuring character and %d is how many times it is given.\n", test_str, pointer, occurrences);



	return 0;
}