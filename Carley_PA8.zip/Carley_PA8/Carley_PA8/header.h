/*
Programmer name: Sarah Carley
Date made: 11/29/22
Date last modified: 11/29/22
Description: This is where the functions will be called and libraries included
*/

#ifndef HEADER_H
#define HEADER_H
#define _CRT_SECURE_NO_WARNINGS


#include<stdio.h>
#include<math.h>
#include<string.h>


typedef struct occurrences

{

    int num_occurrences;

    double frequency;

} Occurrences;


/*
 Function: binary_search()
 Date Created: 11/29/22
 Date Last Modified: 11/29/22
 Description: This checks to see if the target value is inside the sorted table
 Input parameters: the table, the size, and the target
 Returns: the index it is found at
 Preconditions: the table's values must be sorted
 Postconditions: the index is returned
*/
int binary_search(int table[], int size, int target);

/*
 Function: my_str_n_cat()
 Date Created: 12/3/22
 Date Last Modified: 12/3/22
 Description: This appends another string onto the first
 Input parameters: the pointer to the destination, the pointer to the source, and the number of max characters to append
 Returns: the destination
 Preconditions: the input parameters must exist
 Postconditions: the destination is updated and returned
*/
char* my_str_n_cat(char* destination, char* source, int n);

/*
 Function: bubble_sort()
 Date Created: 12/3/22
 Date Last Modified: 12/3/22
 Description: This orders the array of pointers to strings
 Input parameters: the array and the number of strings
 Returns: nothing
 Preconditions: the input parameters must exist
 Postconditions: N/A
*/
void bubble_sort(char* array[], int num_of_strs);

/*
 Function: is_palindrome()
 Date Created: 12/4/22
 Date Last Modified: 12/4/22
 Description: recursively determines if tge string given is a palindrome
 Input parameters: the pointer to the string and the size
 Returns: whether or not the string is a palindrome
 Preconditions: the input parameters must exist
 Postconditions: whether or not the string is a palindrome is returned
*/
int is_palindrome(char* string, int size);

/*
 Function: sum_primes()
 Date Created: 12/4/22
 Date Last Modified: 12/4/22
 Description: recursively finds the sum of all primes under (& including) the number
 Input parameters: the number
 Returns: The sum of the primes
 Preconditions: the input parameters must exist
 Postconditions: The sum
*/
int sum_primes(int n);

/*
 Function: maximum_occurrences()
 Date Created: 12/5/22
 Date Last Modified: 12/5/22
 Description: Finds what letter in a given string occurs the most
 Input parameters: the string, the array of structs, the number pointer, and the character pointer
 Returns: nothing
 Preconditions: the input parameters must exist
 Postconditions: The number, character, and struct pointers are modified
*/
void maximum_occurrences(char* string, Occurrences* array, int* number, char* character);



#endif