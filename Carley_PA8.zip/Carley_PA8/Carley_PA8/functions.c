/*
Programmer name: Sarah Carley
Date made: 11/29/22
Date last modified: 11/29/22
Description: This is where the functions will be made in the program
*/

#include "header.h"


/*
 Function: binary_search()
 Date Created: 11/29/22
 Date Last Modified: 11/29/22
 Description: This checks to see if the target value is inside the sorted table
 Input parameters: the table, the size, and the target
 Returns: the index it is found at
 Preconditions: the table's values must be sorted
 Postconditions: the index is returned
*/
int binary_search(int table[], int size, int target)
{
	int found = 0, right = size - 1, left = 0;
	int target_index = -1, mid = 0;
	while (found == 0 && left <= right)
	{
		mid = (left + right) / 2;
		if (target == table[mid])
		{
			found = 1;
			target_index = mid;
		}
		else if (target < table[mid])
		{
			right = mid - 1;
		}
		else if (target > table[mid])
		{
			left = mid + 1;
		}
	}
	return target_index;
}

/*
 Function: my_str_n_cat()
 Date Created: 12/3/22
 Date Last Modified: 12/3/22
 Description: This appends another string onto the first
 Input parameters: the pointer to the destination, the pointer to the source, and the number of max characters to append
 Returns: the destination
 Preconditions: the input parameters must exist
 Postconditions: the destination is updated and returned
*/
char* my_str_n_cat(char* destination, char* source, int n)
{
	int loops = 0;
	while (*destination != '\0')
	{
		//printf("%c", *destination);
		destination++;
	}
	while (*source != '\0' && loops < n)
	{
		*destination = *source;
		/*printf("%c", *source);*/
		destination++;
		source++;
		loops++;
	}
	*destination = '\0';
	return destination;
}

/*
 Function: bubble_sort()
 Date Created: 12/3/22
 Date Last Modified: 12/3/22
 Description: This orders the array of pointers to strings
 Input parameters: the array and the number of strings
 Returns: nothing
 Preconditions: the input parameters must exist
 Postconditions: N/A
*/
void bubble_sort(char* array[], int num_of_strs)
{
	int U = num_of_strs - 1, C = 0;
	char* temp;
	while (U > 1)
	{
		C = 1;
		while (C <= U)
		{
			if (array[C] < array[C - 1])
			{
				temp = array[C];
				array[C] = array[C - 1];
				array[C - 1] = temp;
			}
			C++;
		}
		U--;
	}
}

/*
 Function: is_palindrome()
 Date Created: 12/4/22
 Date Last Modified: 12/4/22
 Description: recursively determines if tge string given is a palindrome
 Input parameters: the pointer to the string and the size
 Returns: whether or not the string is a palindrome
 Preconditions: the input parameters must exist
 Postconditions: whether or not the string is a palindrome is returned
*/
int is_palindrome(char* string, int size)
{

	//printf("%c", string[size]);
	static int count = 0, palin = 0;
	int result = 0, og_size = strlen(string);
	if (string[size - 1] == '\0');
	else
	{
		count += is_palindrome(string, size - 1);
		char copy = string[og_size - 1 - palin];
		if (string[size-1] == copy)
		{
			palin++;
		}
		string++;
	}
	if (palin >= size - 1)
	{
		result = 1;
	}
	
	return result;
}

/*
 Function: sum_primes()
 Date Created: 12/4/22
 Date Last Modified: 12/4/22
 Description: recursively finds the sum of all primes under (& including) the number
 Input parameters: the number
 Returns: The sum of the primes
 Preconditions: the input parameters must exist
 Postconditions: The sum
*/
int sum_primes(int n)
{
	int sum = 0;

	if (n % 2 != 0 && n % 3 != 0)
	{
		sum += n;
	}

	if (n == 1)
	{
		sum = 3;
	}
	else
	{
		sum += sum_primes(n - 1);
	}
	
	
	return sum;
}

/*
 Function: maximum_occurrences()
 Date Created: 12/5/22
 Date Last Modified: 12/5/22
 Description: Finds what letter in a given string occurs the most
 Input parameters: the string, the array of structs, the number pointer, and the character pointer
 Returns: nothing
 Preconditions: the input parameters must exist
 Postconditions: The number, character, and struct pointers are modified
*/
void maximum_occurrences(char* string, Occurrences* array, int* number, char* character)
{
	int index = 0, num = 0, length = strlen(string), index2 = 0;
	double frequency = 0.0;
	while (index < length)
	{
		*character = string[index];
		while (string[index2] != '\0')
		{
			if (string[index2] == *character)
			{
				num++;
			}
			index2++;
		}
		array[index].num_occurrences = num;
		array[index].frequency = (double) num / length;
		index++;
		index2 = 0;
		num = 0;
	}

	index = 0;
	*number = array[index].num_occurrences;
	while (index < length - 1)
	{
		if (array[index + 1].num_occurrences > *number)
		{
			*number = array[index + 1].num_occurrences;
			*character = string[index];
		}
		index++;
	}
}