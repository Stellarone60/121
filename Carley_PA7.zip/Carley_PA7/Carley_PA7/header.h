/*
Programmer name: Sarah Carley
Date made: 11/14/22
Date last modified: 11/14/22
Description: This is where libraries will be included and functions defined
*/

#ifndef HEADER_H
#define HEADER_H

#define _CRT_SECURE_NO_WARNINGS

#define HAND_SIZE 5

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

typedef struct card
{
	//Where to find the suit in the array (the index)
	int suit;
	//Where to find the face in the array (the index)
	int face;
}Card;

typedef struct hand
{
	Card cards[HAND_SIZE];
}Hand;

/*
 Function: shuffle()
 Date Created: 11/14/22
 Date Last Modified: 11/14/22
 Description: This shuffles the deck
 Input parameters: the deck
 Returns: nothing
 Preconditions: the deck must exist
 Postconditions: The deck is shuffled
*/
void shuffle(int wDeck[][13]);

/*
 Function: set_void_board()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This makes the deck all 0 again
 Input parameters: the deck
 Returns: nothing
 Preconditions: the deck must exist
 Postconditions: The deck is set to 0 everywhere
*/
void set_void_board(int wDeck[][13]);

/*
 Function: deal()
 Date Created: 11/14/22
 Date Last Modified: 11/14/22
 Description: This deals the player their cards
 Input parameters: the deck, the faces, and the suit tables
 Returns: nothing
 Preconditions: the arrays must exist
 Postconditions: The cards are dealt
*/
void deal(const int wDeck[][13], const char* wFace[], const char* wSuit[], Hand* hand);

/*
 Function: one_pair()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has one pair
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is a pair is returned
*/
int one_pair(int freq_table[]);

/*
 Function: two_pair()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has two pairs
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there are two pairs is returned
*/
int two_pair(int freq_table[]);

/*
 Function: three_of_a_kind()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has three of a kind
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is three of a kind is returned
*/
int three_of_a_kind(int freq_table[]);

/*
 Function: four_of_a_kind()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has four of a kind
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is four of a kind is returned
*/
int four_of_a_kind(int freq_table[]);

/*
 Function: full_house()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has a full house
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is a full house is returned
*/
int full_house(int freq_table[]);

/*
 Function: flush()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has a flush
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is a flush is returned
*/
int flush(int suit_freq_table[]);

/*
 Function: straight()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has a straight
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is a straight is returned
*/
int straight(int freq_table[], int smallest_num);

/*
 Function: set_freq_table()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: sets the face frequency table
 Input parameters: the frequency table, the poiner to the player's hand
 Returns: nothing
 Preconditions: the frequency table must have values saved to it, the hand must exist
 Postconditions: The frequency table is updated
*/
void set_freq_table(Hand* hand, int freq_table[]);

/*
 Function: set_suit_freq_table()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: sets the face frequency table
 Input parameters: the frequency table, the poiner to the player's hand
 Returns: nothing
 Preconditions: the frequency table must have values saved to it, the hand must exist
 Postconditions: The frequency table is updated
*/
void set_suit_freq_table(Hand* hand, int freq_table[]);

/*
 Function: print_game_rules()
 Date Created: 11/26/22
 Date Last Modified: 11/26/22
 Description: prints the game rules
 Input parameters: none
 Returns: nothing
 Preconditions: none
 Postconditions: The rules are printed
*/
void print_game_rules(void);

/*
 Function: menu()
 Date Created: 11/26/22
 Date Last Modified: 11/26/22
 Description: Prints and gets the player's input for the menu
 Input parameters: none
 Returns: nothing
 Preconditions: none
 Postconditions: The choice is returned
*/
int menu(void);

/*
 Function: set_void_1d()
 Date Created: 11/26/22
 Date Last Modified: 11/26/22
 Description: Sets a 1d array to all 0's
 Input parameters: the array and the size
 Returns: nothing
 Preconditions: none
 Postconditions: The board becomes all 0's
*/
void set_void_1d(int array[], int size);

/*
 Function: find_min()
 Date Created: 11/26/22
 Date Last Modified: 11/26/22
 Description: Finds the minimum value in the hand
 Input parameters: the hand
 Returns: nothing
 Preconditions: none
 Postconditions: returns the min
*/
int find_min(Hand hand);

/*
 Function: redraw()
 Date Created: 11/26/22
 Date Last Modified: 11/26/22
 Description: redraws up to three cards in the hand
 Input parameters: the hand, the deck, the suit table, the face table, and the number of redraws to be done
 Returns: nothing
 Preconditions: the tables must have values
 Postconditions: the hand is changed
*/
void redraw_cards(const int wDeck[][13], const char* wFace[], const char* wSuit[], Hand* hand, int redraw, int player);

/*
 Function: win_string()
 Date Created: 11/28/22
 Date Last Modified: 11/28/22
 Description: puts what the player wins with into an array
 Input parameters: the string and the two player scores
 Returns: nothing
 Preconditions: none (this could work if all are empty/invalid)
 Postconditions: the string is changed if a player scored
*/
void win_string(char* string, int p1_score, int p2_score);



#endif