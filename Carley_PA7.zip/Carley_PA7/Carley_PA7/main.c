/*
Programmer name: Sarah Carley
Date made: 11/14/22
Date last modified: 11/26/22
Description: This is the main function where all the program will be based
*/

#include "header.h"


int main(void)
{
	/* initialize suit array */
	//Create a frequency table that keeps track of how many of each card there is. 0-12
	int p1_freq_table[13] = { 0 }, p2_freq_table[13] = { 0 }, p1_suit_freq_table[4] = { 0 }, p2_suit_freq_table[4] = { 0 };
	int count = 0, p1_min = 0, p2_min = 0, menu_choice = 0, p1_score = 0, p2_score = 0, redraw_choice = 0, redraw = 0;
	const char* suit[4] = { "Hearts", "Diamonds", "Clubs", "Spades" };
	char winner_string[20] = "";

	/* initialize face array */
	const char* face[13] = { "Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight",
		"Nine", "Ten", "Jack", "Queen", "King" };

	/* initalize deck array */
	int deck[4][13] = { 0 };

	srand((unsigned)time(NULL)); /* seed random-number generator */

	shuffle(deck);

	//Creates the structs for the hands
	Hand p1_hand;
	Hand p2_hand;

	menu_choice = menu();
	while (menu_choice != 3)
	{
		switch (menu_choice)
		{
		case 1:
			print_game_rules();
			break;
		case 2:

			//resets all the tables if the game is played again
			set_void_1d(p1_freq_table, 13);
			set_void_1d(p2_freq_table, 13);
			set_void_1d(p1_suit_freq_table, 4);
			set_void_1d(p2_suit_freq_table, 4);
			redraw_choice = 0, redraw = 0;

			//Deals player 1 their cards
			deal(deck, face, suit, &p1_hand);


			//printf("\n%d\n%d\n\n\n", p1_hand.cards->face, p1_hand.cards->suit);

			//Shows player 1 their hand
			printf("Player 1's Hand:\n");
			while (count < 5)
			{
				//Prints the cards
				printf("Card %d:  %5s of %-8s\n", count + 1, face[p1_hand.cards[count].face], suit[p1_hand.cards[count].suit]);
				count++;
			}
			//Checks for redraws
			do
			{
				printf("Would you like to redraw up to three cards?\n1: Yes\n2: No\n");
				scanf("%d", &redraw_choice);
				
			} while (redraw_choice < 1 || redraw_choice > 2);
			if (redraw_choice == 1)
			{
				do
				{
					printf("How many cards would you like to redraw?\n");
					scanf("%d", &redraw);
				} while (redraw < 1 || redraw > 3);
				redraw_cards(deck, face, suit, &p1_hand, redraw, 1);
				system("pause");
				system("cls");
				//Shows player 1 their hand
				printf("\nPlayer 1's Hand:\n");
				count = 0;
				while (count < 5)
				{
					//Prints the cards
					printf("Card %d:  %5s of %-8s\n", count + 1, face[p1_hand.cards[count].face], suit[p1_hand.cards[count].suit]);
					count++;
				}
			}


			//Sets the frequency table
			set_freq_table(&p1_hand, p1_freq_table);
			set_suit_freq_table(&p1_hand, p1_suit_freq_table);

			//Finds the minimum for later use
			p1_min = find_min(p1_hand);

			//sets count back to 0
			count = 0;

			//Sets the deck back to 0
			set_void_board(deck);

			//Shuffles and deals the deck to player 2
			shuffle(deck);
			deal(deck, face, suit, &p2_hand);

			//Finds the min for later use
			p2_min = find_min(p2_hand);

			//If the dealer has no points, they will redraw up to three cards at random
			//Checks for four of a kind
			p2_score = four_of_a_kind(p2_freq_table);
			//If there's no four of a kind
			if (p2_score == 0)
			{
				//Checks for full house
				p2_score = full_house(p2_freq_table);
				//If there is no full house
				if (p2_score == 0)
				{
					//Check for flush
					p2_score = flush(p2_suit_freq_table);
					//if there is no flush
					if (p2_score == 0)
					{
						//checks for straight
						p2_score = straight(p2_freq_table, p2_min);
						//if there is no straight
						if (p2_score == 0)
						{
							//checks for three of a kind
							p2_score = three_of_a_kind(p2_freq_table);
							//if there is no three of a kind
							if (p2_score == 0)
							{
								//checks for two pairs
								p2_score = two_pair(p2_freq_table);
								//if there are not two pairs
								if (p2_score == 0)
								{
									//checks for one pair
									p2_score = one_pair(p2_freq_table);
								}
							}
						}
					}
				}
			}


			//This will decide whether or not the second player will redraw any cards
			if (p2_score == 0)
			{
				redraw = rand() % 3 + 1;
				redraw_cards(deck, face, suit, &p2_hand, redraw, 2);
			}

			//Gonna get rid of this later for no cheating
			//printf("Player 2's Hand:\n");
			//while (count < 5)
			//{
			//	printf("Card %d:  %5s of %-8s\n", count + 1, face[p2_hand.cards[count].face], suit[p2_hand.cards[count].suit]);
			//	count++;
			//}
			set_freq_table(&p2_hand, p2_freq_table);
			set_suit_freq_table(&p2_hand, p2_suit_freq_table);

			//Checking for the scores
			//I could make a function but with all the functions called within this set of nested statements, it feels unsafe
			p1_score = four_of_a_kind(p1_freq_table);
			//Checks for four of a kind
			printf("Four of a kind: %d\n", p1_score);
			//If there's no four of a kind
			if (p1_score == 0)
			{
				//Checks for full house
				p1_score = full_house(p1_freq_table);
				printf("Full House: %d\n", p1_score);
				//If there is no full house
				if (p1_score == 0)
				{
					//Check for flush
					p1_score = flush(p1_suit_freq_table);
					printf("Flush: %d\n", p1_score);
					//if there is no flush
					if (p1_score == 0)
					{
						//checks for straight
						p1_score = straight(p1_freq_table, p1_min);
						printf("Straight: %d\n", p1_score);
						//if there is no straight
						if (p1_score == 0)
						{
							//checks for three of a kind
							p1_score = three_of_a_kind(p1_freq_table);
							printf("Three of a kind: %d\n", p1_score);
							//if there is no three of a kind
							if (p1_score == 0)
							{
								//checks for two pairs
								p1_score = two_pair(p1_freq_table);
								printf("Two pair: %d\n", p1_score);
								//if there are not two pairs
								if (p1_score == 0)
								{
									//checks for one pair
									p1_score = one_pair(p1_freq_table);
									printf("One pair: %d\n", p1_score);
								}
							}
						}
					}
				}
			}
			//Checks for four of a kind
			p2_score = four_of_a_kind(p2_freq_table);
			//If there's no four of a kind
			if (p2_score == 0)
			{
				//Checks for full house
				p2_score = full_house(p2_freq_table);
				//If there is no full house
				if (p2_score == 0)
				{
					//Check for flush
					p2_score = flush(p2_suit_freq_table);
					//if there is no flush
					if (p2_score == 0)
					{
						//checks for straight
						p2_score = straight(p2_freq_table, p2_min);
						//if there is no straight
						if (p2_score == 0)
						{
							//checks for three of a kind
							p2_score = three_of_a_kind(p2_freq_table);
							//if there is no three of a kind
							if (p2_score == 0)
							{
								//checks for two pairs
								p2_score = two_pair(p2_freq_table);
								//if there are not two pairs
								if (p2_score == 0)
								{
									//checks for one pair
									p2_score = one_pair(p2_freq_table);
								}
							}
						}
					}
				}
			}
			system("pause");
			//Determines who wins
			if (p1_score > p2_score)
			{
				//This sets the winning string to what was won with
				win_string(winner_string, p1_score, 0);
				printf("\nPlayer 1 wins with %s!\n\n", winner_string);
			}
			else if (p1_score < p2_score)
			{
				//This sets the winning string to what was won with
				win_string(winner_string, 0, p2_score);
				printf("\nThe dealer wins with %s!\n\n", winner_string);
			}
			else
			{
				printf("\nThis ends in a tie!\n\n");
			}


			break;
		}

		system("pause");
		system("cls");
		menu_choice = menu();
	}


	

	return 0;
}