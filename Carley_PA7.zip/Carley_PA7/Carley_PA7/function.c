/*
Programmer name: Sarah Carley
Date made: 11/14/22
Date last modified: 11/14/22
Description: This is where all the functions will be made so they can be called later in main
*/



#include "header.h"


/* shuffle cards in deck */
/*
 Function: shuffle()
 Date Created: 11/14/22
 Date Last Modified: 11/14/22
 Description: This shuffles the deck
 Input parameters: the deck
 Returns: nothing
 Preconditions: the deck must exist
 Postconditions: The deck is shuffled
*/
void shuffle(int wDeck[][13])
{
	int row = 0;    /* row number */
	int column = 0; /*column number */
	int card = 0;   /* card counter */

	/* for each of the 52 cards, choose slot of deck randomly */
	for (card = 1; card <= 52; card++)
	{
		/* choose new random location until unoccupied slot found */
		do
		{
			row = rand() % 4;
			column = rand() % 13;
		} while (wDeck[row][column] != 0);

		/* place card number in chosen slot of deck */
		wDeck[row][column] = card;
	}
}

/*
 Function: set_void_board()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This makes the deck all 0 again
 Input parameters: the deck
 Returns: nothing
 Preconditions: the deck must exist
 Postconditions: The deck is set to 0 everywhere
*/
void set_void_board(int wDeck[][13])
{
    int row = 0, col = 0;
    for (row = 0; row < 4; row++)
    {
        for (col = 0; col < 13; col++)
        {
            wDeck[row][col] = 0;
        }
    }
}



/* deal cards in deck */
/*
 Function: deal()
 Date Created: 11/14/22
 Date Last Modified: 11/14/22
 Description: This deals the player their cards
 Input parameters: the deck, the faces, and the suit tables
 Returns: nothing
 Preconditions: the arrays must exist
 Postconditions: The cards are dealt
*/
void deal(const int wDeck[][13], const char* wFace[], const char* wSuit[], Hand* hand)
{
	int row = 0;    /* row number */
	int column = 0; /*column number */
	int card = 0;   /* card counter */
	int count = 0;

	/* deal each of the 52 cards */
	for (card = 1; card <= 5; card++, count++)
	{
		/* loop through rows of wDeck */
		for (row = 0; row <= 3; row++)
		{
			/* loop through columns of wDeck for current row */
			for (column = 0; column <= 12; column++)
			{
				/* if slot contains current card, display card */
				if (wDeck[row][column] == card)
				{
					//the "card % 2 == 0 ? '\n' : '\t' " if the before the ? statement is true the '\n' will be executed.
					//If not, the '\t' will be executed
					//printf("%5s of %-8s%c", wFace[column], wSuit[row], card % 2 == 0 ? '\n' : '\t');
					hand->cards[count].face = column;
					hand->cards[count].suit = row;
				}
			}
		}
	}
}


/*
 Function: one_pair()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has one pair
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is a pair is returned
*/
int one_pair(int freq_table[])
{
    int result = 0, index = 0;
    while (index < 12)
    {
        if (freq_table[index] >= 2)
        {
            result = 1;
        }
        index++;
    }
    return result;
}


/*
 Function: two_pair()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has two pairs
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there are two pairs is returned
*/
int two_pair(int freq_table[])
{
    int result = 0, index = 0, pairs = 0;
    while (index < 12)
    {
        if (freq_table[index] >= 2)
        {
            pairs++;
        }
        index++;
    }
    if (pairs == 2)
    {
        result = 2;
    }
    return result;
}


/*
 Function: three_of_a_kind()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has three of a kind
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is three of a kind is returned
*/
int three_of_a_kind(int freq_table[])
{
    int index = 0, result = 0;
    while (index < 12)
    {
        if (freq_table[index] >= 3)
        {
            result = 3;
        }
        index++;
    }
    return result;
}


/*
 Function: four_of_a_kind()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has four of a kind
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is four of a kind is returned
*/
int four_of_a_kind(int freq_table[])
{
    int index = 0, result = 0;
    while (index < 12)
    {
        if (freq_table[index] >= 4)
        {
            result = 7;
        }
        index++;
    }
    return result;
}


/*
 Function: full_house()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has a full house
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is a full house is returned
*/
int full_house(int freq_table[])
{
    int index = 0, check1 = 0, check = 0, result = 0;
    while (index < 12)
    {
        if (freq_table[index] == 3)
        {
            check1++;
        }
        else if (freq_table[index] == 2)
        {
            if (check != 1)
            {
                check++;
            }
        }
        index++;
    }
    if (check == 1 && check1 == 1)
    {
        result = 6;
    }
    return result;
}


/*
 Function: flush()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has a flush
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is a flush is returned
*/
int flush(int suit_freq_table[])
{
    int index = 0, result = 0;
    while (index < 3)
    {
        if (suit_freq_table == 5)
        {
            result = 5;
        }
        index++;
    }
    return result;
}


/*
 Function: straight()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: This checks to see if the hand has a straight
 Input parameters: the frequency table
 Returns: nothing
 Preconditions: the frequency table must have values saved to it
 Postconditions: Whether or not there is a straight is returned
*/
int straight(int freq_table[], int smallest_num)
{
    int result = 0, adder = 0, check = 0;
    while (adder < 4)
    {
        if (freq_table[smallest_num + adder] == 1)
        {
            check++;
        }
        adder++;
    }
    if (check == 4)
    {
        result = 4;
    }
    return result;
}

/*
 Function: set_freq_table()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: sets the face frequency table
 Input parameters: the frequency table, the poiner to the player's hand
 Returns: nothing
 Preconditions: the frequency table must have values saved to it, the hand must exist
 Postconditions: The frequency table is updated
*/
void set_freq_table(Hand* hand, int freq_table[])
{
    int index = 0;
    while (index < 5)
    {
        freq_table[hand->cards[index].face] = freq_table[hand->cards[index].face] + 1;
        index++;
    }
}

/*
 Function: set_suit_freq_table()
 Date Created: 11/25/22
 Date Last Modified: 11/25/22
 Description: sets the face frequency table
 Input parameters: the frequency table, the poiner to the player's hand
 Returns: nothing
 Preconditions: the frequency table must have values saved to it, the hand must exist
 Postconditions: The frequency table is updated
*/
void set_suit_freq_table(Hand* hand, int freq_table[])
{
    int index = 0;
    while (index < 5)
    {
        //printf("%d\n", hand->cards[index].suit);
        freq_table[hand->cards[index].suit] += 1;
        index++;
    }
}

/*
 Function: print_game_rules()
 Date Created: 11/26/22
 Date Last Modified: 11/26/22
 Description: prints the game rules
 Input parameters: none
 Returns: nothing
 Preconditions: none
 Postconditions: The rules are printed
*/
void print_game_rules(void)
{
    printf("This is five card poker. You and the dealer will draw five cards. Once the cards have been drawn, you will decide if you want ");
    printf("to redraw up to three. four of a kind is worth the most, then full house, then flush, then straight, then three of a kind, then ");
    printf("two pairs, then a single pair.\n");
}

/*
 Function: menu()
 Date Created: 11/26/22
 Date Last Modified: 11/26/22
 Description: Prints and gets the player's input for the menu
 Input parameters: none
 Returns: nothing
 Preconditions: none
 Postconditions: The choice is returned
*/
int menu(void)
{
    int choice = 0;
    do
    {
        printf("1: Display game rules\n2: Play five-card draw\n3: Exit\n");
        scanf("%d", &choice);
    } while (choice < 1 || choice > 3);
    return choice;
}

/*
 Function: set_void_1d()
 Date Created: 11/26/22
 Date Last Modified: 11/26/22
 Description: Sets a 1d array to all 0's
 Input parameters: the array and the size
 Returns: nothing
 Preconditions: none
 Postconditions: The board becomes all 0's
*/
void set_void_1d(int array[], int size)
{
    int index = 0;
    while (index < size)
    {
        array[index] = 0;
        index++;
    }
}

/*
 Function: find_min()
 Date Created: 11/26/22
 Date Last Modified: 11/26/22
 Description: Finds the minimum value in the hand
 Input parameters: the hand
 Returns: nothing
 Preconditions: none
 Postconditions: returns the min
*/
int find_min(Hand hand)
{
    int index = 0, min = 0;
    min = hand.cards[index].face;
    index++;
    while (index < 12)
    {
        if (hand.cards[index].face < min)
        {
            min = hand.cards[index].face;
        }
        index++;
    }
}

/*
 Function: redraw_cards()
 Date Created: 11/26/22
 Date Last Modified: 11/28/22
 Description: redraws up to three cards in the hand
 Input parameters: the hand, the deck, the suit table, the face table, and the number of redraws to be done
 Returns: nothing
 Preconditions: the tables must have values
 Postconditions: the hand is changed
*/
void redraw_cards(const int wDeck[][13], const char* wFace[], const char* wSuit[], Hand* hand, int redraw, int player)
{
    int row = 0;    /* row number */
    int column = 0; /*column number */
    int card = 0;   /* card counter */
    int count = 0;
    int choice1 = 0, choice2 = 0, choice3 = 0;
    if (player == 1)
    {
        do
        {
            printf("\nWhich card would you like to replace?\n");
            scanf("%d", &choice1);
        } while (choice1 < 1 || choice1 > 5);
        choice1 -= 1;
    }
    else
    {
        choice1 = rand() % 5 + 1;
    }
    card = 6;
    /* loop through rows of wDeck */
    for (row = 0; row <= 3; row++)
    {
        /* loop through columns of wDeck for current row */
        for (column = 0; column <= 12; column++)
        {
            /* if slot contains current card, display card */
            if (wDeck[row][column] == card)
            {
                //the "card % 2 == 0 ? '\n' : '\t' " if the before the ? statement is true the '\n' will be executed.
                //If not, the '\t' will be executed
                if (player == 1)
                {
                    printf("%5s of %-8s%c", wFace[column], wSuit[row], card % 2 == 0 ? '\n' : '\t');
                }  
                hand->cards[choice1].face = column;
                hand->cards[choice1].suit = row;
            }
        }
    }
    
    if (redraw > 1)
    {
        if (player == 1)
        {
            do
            {
                printf("\nWhich card would you like to replace?\n");
                scanf("%d", &choice2);
            } while (choice2 < 1 || choice2 > 5 || choice2 == choice1 + 1);
            choice2 -= 1;
        }
        else
        {
            do
            {
                choice2 = rand() % 5 + 1;
            } while (choice2 == choice1 + 1);
            choice2 -= 1;
        }
        card = 7;
        /* loop through rows of wDeck */
        for (row = 0; row <= 3; row++)
        {
            /* loop through columns of wDeck for current row */
            for (column = 0; column <= 12; column++)
            {
                /* if slot contains current card, display card */
                if (wDeck[row][column] == card)
                {
                    //the "card % 2 == 0 ? '\n' : '\t' " if the before the ? statement is true the '\n' will be executed.
                    //If not, the '\t' will be executed
                    if (player == 1)
                    {
                        printf("%5s of %-8s%c", wFace[column], wSuit[row], card % 2 == 0 ? '\n' : '\t');
                    }
                    hand->cards[choice2].face = column;
                    hand->cards[choice2].suit = row;
                }
            }
        }
    }

    if (redraw == 3)
    {
        if (player == 1)
        {
            do
            {
                printf("\nWhich card would you like to replace?\n");
                scanf("%d", &choice3);
            } while (choice3 < 1 || choice3 > 5 || choice3 == choice2 + 1 || choice3 == choice1 + 1);
            choice3 -= 1;
        }
        else
        {
            do
            {
                choice3 = rand() % 5 + 1;
            } while (choice3 == choice1 + 1 || choice3 == choice2 + 1);
            choice3 -= 1;
        }
        card = 8;
        /* loop through rows of wDeck */
        for (row = 0; row <= 3; row++)
        {
            /* loop through columns of wDeck for current row */
            for (column = 0; column <= 12; column++)
            {
                /* if slot contains current card, display card */
                if (wDeck[row][column] == card)
                {
                    //the "card % 2 == 0 ? '\n' : '\t' " if the before the ? statement is true the '\n' will be executed.
                    //If not, the '\t' will be executed
                    if (player == 1)
                    {
                        printf("%5s of %-8s%c", wFace[column], wSuit[row], card % 2 == 0 ? '\n' : '\t');
                    }
                    hand->cards[choice3].face = column;
                    hand->cards[choice3].suit = row;
                }
            }
        }
    }

}

/*
 Function: win_string()
 Date Created: 11/28/22
 Date Last Modified: 11/28/22
 Description: puts what the player wins with into an array
 Input parameters: the string and the two player scores
 Returns: nothing
 Preconditions: none (this could work if all are empty/invalid)
 Postconditions: the string is changed if a player scored
*/
void win_string(char string[20], int p1_score, int p2_score)
{
    if (p1_score == 1 || p2_score == 1)
    {
        strcpy(string, "a pair");
    }
    else if (p1_score == 2 || p2_score == 2)
    {
        strcpy(string, "two pairs");
    }
    else if (p1_score == 3 || p2_score == 3)
    {
        strcpy(string, "three-of-a-kind");
    }
    else if (p1_score == 4 || p2_score == 4)
    {
        strcpy(string, "a straight");
    }
    else if (p1_score == 5 || p2_score == 5)
    {
        strcpy(string, "a flush");
    }
    else if (p1_score == 6 || p2_score == 6)
    {
        strcpy(string, "a full house");
    }
    else if (p1_score == 7 || p2_score == 7)
    {
        strcpy(string, "four-of-a-kind");
    }
}